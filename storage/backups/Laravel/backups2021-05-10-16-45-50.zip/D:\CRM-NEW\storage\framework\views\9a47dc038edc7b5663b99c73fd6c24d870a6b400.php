
<?php $__env->startSection('title','View Note'); ?>
<?php $__env->startSection('header','Note Details'); ?>
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->can('add-note', App\Models\Note::class)): ?>
  <div class="pull-left">
    <a class="btn btn-primary" href="/addNote">Add new note <span data-feather="plus"></a>
  </div>
<?php endif; ?>
  <br> 
  <br> 
  <?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
<div class="container " style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
          <br>
          <form action="/Search_Notes" method="GET" role="search">
            <?php echo e(csrf_field()); ?>

            <div class="input-group">
              <input type="text" class="form-control" name="query" id="query" placeholder="Search Notes"> 
              <span class="input-group-btn">
                <button type="submit" class="btn btn-default">
                  <span class="glyphicon glyphicon-search"></span>
                </button>
              </span>
            </div>
          </form>
          </br>
          </br>
          <div class="table-responsive">
          <table>
            <tr >
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('NoteID'));?></th>
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Description'));?></th>
              <th >Type</th>
              <th >Images</th>
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Added_By'));?></th>
              <th >Action</th>
            </tr>
            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>                                                
              <th scope="row"><?php echo e($note['NoteID']); ?></th>
              <td style="text-align: left"><?php echo e($note['Description']); ?></td>
              <td><?php echo e($note['Type']); ?></td>
              <td> <img src="<?php echo e(asset('uploads/note/'.$note->image)); ?>"
                class="img-circle" width="100px;" height="100px;" alt="Note-Image">  
              </td>
              <td><?php echo e($note['Added_By']); ?></td>
              <td>
                <?php if(Auth::user()->can('edit-note', App\Models\Note::class)): ?>
                  <a href= "/UpdateNote/<?php echo e($note['NoteID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a> 
                <?php endif; ?>   
                <?php if(Auth::user()->can('delete-note', App\Models\Note::class)): ?>                           
                  <a href= "/DeleteNote/<?php echo e($note['NoteID']); ?>" style="margin:10px" class="text-my-own-color"  onclick="return confirm('Are you sure you want to delete this item?');"><span data-feather ="trash-2"></span></a> 
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </div>
          <br>
          <br> 
          <?php echo $notes->appends(\Request::except('page'))->render(); ?>

        </div>
      </div>
    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\notes\viewnote.blade.php ENDPATH**/ ?>