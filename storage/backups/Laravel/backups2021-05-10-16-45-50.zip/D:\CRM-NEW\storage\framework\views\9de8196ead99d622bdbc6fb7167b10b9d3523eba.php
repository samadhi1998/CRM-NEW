
<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- load the view from type and view_namespace attribute if set -->
    <?php
        $fieldsViewNamespace = $field['view_namespace'] ?? 'crud::fields';
    ?>

    <?php echo $__env->make($fieldsViewNamespace.'.'.$field['type'], ['field' => $field, 'inlineCreate' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <!--  This is where modal fields assets are pushed.
        We bind the modal content including what fields pushed to this stacks to the end of the body tag,
        so we make sure all backpack assets are previously loaded, like jquery etc.

        We can give the same stack name because backpack `crud_fields_scripts` is already rendered and
        this is the only available when rendering the modal html.
    -->
<?php echo $__env->yieldPushContent('crud_fields_scripts'); ?>

<?php echo $__env->yieldPushContent('crud_fields_styles'); ?>

<?php /**PATH D:\CRM-NEW\vendor\backpack\crud\src\resources\views\crud\fields\relationship\show_fields.blade.php ENDPATH**/ ?>