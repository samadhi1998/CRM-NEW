
<?php $__env->startSection('title','Sales Report'); ?>
<?php $__env->startSection('header','Daily Sales Report'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="container-fluid">
        <div class="col-md">           
            <form action="<?php echo e(route('report')); ?>" method="get">          
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        ---Select Report Cetogory---
                    </button>
                    <br><br>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="http://127.0.0.1:8000/byweekly">Weekly Sales Report</a>
                        <a class="dropdown-item" href="http://127.0.0.1:8000/bymonthly">Monthly Sales Report</a>
                        <a class="dropdown-item" href="http://127.0.0.1:8000/salesreport">Other Sales Report</a>
                    </div>
                    <br><br>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="col-md-12">
                                    <div class="card-body">
                                        <h5>
                                            <span data-feather = "calendar" style="width: 30px; height: 30px" class="text-my-own-color" ></span> 
                                            <span class="text-muted">Date : </span> <?php echo e($date); ?>

                                        </h5>                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="col-md-12">
                                    <div class="card-body">
                                        <h5>
                                            <span data-feather = "shopping-cart" style="width: 30px; height: 30px" class="text-my-own-color" ></span> 
                                            <span class="text-muted">No of Sales : </span> <?php echo e($countInvo); ?>

                                        </h5>                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="col-md-12">
                                    <div class="card-body">
                                        <h5>
                                            <span data-feather = "help-circle" style="width: 30px; height: 30px" class="text-my-own-color" ></span> 
                                            <span class="text-muted">Pending Orders : </span> <?php echo e($countQuo); ?>

                                        </h5>                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                
                </div>
                <br><br>
                <div class="card">          
                    <div class="row invoice-header px-3 py-4">
                        <div class="col-12 text-center">
                            <h3> ABS-CBN CORPORATION </h3>      
                            <h4> Daily Sales Report </h4> 
                            <h5><b> <?php echo e($date); ?> </b></h5>                      
                        </div>           
                        <div class="table-responsive">
                        <?php $total_d = 0; ?>
                            <table>
                                <tr> 
                                    <th>Order No</th>
                                    <th>Customer </th> 
                                    <th>Email </th> 
                                    <th>Date</th>
                                    <th>Items</th>                                                
                                </tr>
                                <?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td ><?php echo e($order->OrderID); ?></td>
                                    <td><?php echo e($order->Customer); ?></td>
                                    <td><?php echo e($order->Email); ?></td>
                                    <td><?php echo e($order->updated_at); ?></td>
                                    <td>
                                        <ul>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                         
                                                <?php if( $order->OrderID === $item->OrderID): ?>
                                                    <?php $__currentLoopData = $item->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($p->Name); ?> (Rs.<?php echo e($p->Price); ?> x <?php echo e($p->pivot->Qty); ?>)</li>
                                                        <?php $total_d = $total_d + ($p->Price * $p->pivot->Qty ); ?>  
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>                               
                                    </td>                              
                                </tr>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                           
                            </table>  
                        </div>
                    </div>  
                    <br><br>
                    <div class="col-sm-3"> 
                        <h5>
                            <span class="text-muted">Total Sales : Rs. </span> <?php echo  number_format  ($total_d)."<br>"; ?>
                        </h5>                                          
                    </div>
                    <div align="right">                              
                        <a class="btn btn-primary" href="http://127.0.0.1:8000/sendpdfdaily">Save as PDF</a> 
                        <a class="btn btn-primary" id="printPageButton" onclick="window.print()">Print</button></a>
                    </div><br>                      
                </div>              
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\reports\bydaily.blade.php ENDPATH**/ ?>