
<?php $__env->startSection('title','Search Reminder'); ?>
<?php $__env->startSection('header','Search Reminder'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
        <div class="table-responsive">
        <table>
              <tr >
                <th >Reminder ID</th>
                <th >Description</th>
                <th >Start Date</th>
                <th >End Date</th>
                <th >Action</th>
              </tr>

              <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>                                                
                <th scope="row"><?php echo e($event['id']); ?></th>
                <td><?php echo e($event['title']); ?></td>
                <td><?php echo e($event['start_date']); ?></td>
                <td><?php echo e($event['end_date']); ?></td>
                <td>
                  <?php if(Auth::user()->can('edit-reminder', App\Models\Event::class)): ?>
                    <a href= "/editeventurl/update/<?php echo e($event['id']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a>                           
                  <?php endif; ?>
                  <?php if(Auth::user()->can('delete-reminder', App\Models\Eveent::class)): ?> 
                    <a href= "/deleteeventurl/<?php echo e($event['id']); ?>" style="margin:10px" class="text-my-own-color"><span data-feather ="trash-2"></span></a> 
                  <?php endif; ?>
                </td>
              </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
          </br>
          </br>

          <?php echo e($events->links()); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
          </br>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\Reminder\searchReminder.blade.php ENDPATH**/ ?>