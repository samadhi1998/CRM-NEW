
<?php $__env->startSection('title','View Roles'); ?>
<?php $__env->startSection('header','View Roles'); ?>
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->can('add-role', App\Models\Role::class)): ?>
<div class="pull-left">
    <a class="btn btn-primary" href="/Create-Role">Add Role <span data-feather="plus"></a>
</div>
<?php endif; ?>
<br>
<br>
<?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
        <br>
        <div class="table-responsive">
          <table>
            <tr>
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('RoleID'));?></th>
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
              <th >Action</th>
            </tr>
            <?php if($roles->count()): ?>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="text-align: center"><?php echo e($role['RoleID']); ?></td>
              <td style="text-align: left"><?php echo e($role['name']); ?></td>
              <td>
              <?php if(Auth::user()->can('edit-role', App\Models\Role::class)): ?>
              <a href="roleedit/<?php echo e($role->RoleID); ?>" class="text-my-own-color" style="margin:2px" ><span data-feather="edit"></span></a>
              <?php endif; ?>
              <?php if(Auth::user()->can('delete-role', App\Models\User::class)): ?>
              <a href="/deleteRole/<?php echo e($role->RoleID); ?>" class="text-my-own-color" style="margin:2px" onclick="return confirm('Are you sure you want to delete this item?');"><span data-feather="trash-2"></span></a>
              <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </table>
        </div>
          <br>
          <br>
          <?php echo $roles->appends(\Request::except('page'))->render(); ?>

        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="color:#233554">Delete Alert</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body" style="color:#233554">
                You are going to delete the records of role id <?php echo e($role->RoleID); ?> . Do you want to continue ?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                <a href="/deleteRole/<?php echo e($role->RoleID); ?>"><button type="submit" form="myformproduct" class="btn btn-primary">Continue</button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\admin\users\viewrole.blade.php ENDPATH**/ ?>