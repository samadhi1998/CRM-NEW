<!DOCTYPE html>
<html>
<head>
    <title>buyabc@abcgroup.com</title>
</head>
<body>

    <h1></h1>
    
    <div class="container">
    <div class="row invoice-header px-3 py-4">
        <div class="col-12 text-center">
            <h2 class="Name">ABS-CBN CORPORATION</h2>
            <h6>No.95, Galle Road, Moratuwa</h6>
            <h6>Tel : +(94) 112 605 731</h6>
            <h6><a href="mailto:buyabc@abcgroup.com">email : buyabc@abcgroup.com</a></h6>
            <hr>
        </div> 
    </div>
    

    <p>Dear Mr. Madam/Sir,</p>   

    <p>
       Thank you for placing an order with us.<br><br>
       If you need our products or services in the future, kindly let us know.<br>
       In case if you have any clarification, please contact us.<br><br>
       We have attached the Invoice in below<br><br>
    </p>

    <p>Thank you</p>

    <p>Sincerely,<br>Sales manager</p>
   
</body>
</html>