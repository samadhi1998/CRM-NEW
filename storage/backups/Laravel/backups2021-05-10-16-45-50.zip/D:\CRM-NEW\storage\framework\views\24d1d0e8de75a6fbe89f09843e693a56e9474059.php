
<?php $__env->startSection('title','Search Note'); ?>
<?php $__env->startSection('header','Search Note'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
        <div class="table-responsive">
        <table>
            <tr >
              <th >Note ID</th>
              <th >Description</th>
              <th >Type</th>
              <th >Images</th>
              <th >Added By</th>
              <th >Action</th>
            </tr>
            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>                                                
              <th scope="row"><?php echo e($note['NoteID']); ?></th>
              <td><?php echo e($note['Description']); ?></td>
              <td><?php echo e($note['Type']); ?></td>
              <td> <img src="<?php echo e(asset('uploads/note/'.$note->image)); ?>"
                class="img-circle" width="100px;" height="100px;" alt="Note-Image">  
              </td>
              <td><?php echo e($note['Added_By']); ?></td>
              <td>
                <?php if(Auth::user()->can('edit-note', App\Models\Note::class)): ?>
                  <a href= "/UpdateNote/<?php echo e($note['NoteID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a> 
                <?php endif; ?>   
                <?php if(Auth::user()->can('delete-note', App\Models\Note::class)): ?>                           
                  <a href= "/DeleteNote/<?php echo e($note['NoteID']); ?>" style="margin:10px" class="text-my-own-color"><span data-feather ="trash-2"></span></a> 
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </div>
          </br>
          </br>

          <?php echo e($notes->links()); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
          </br>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\notes\searchNote.blade.php ENDPATH**/ ?>