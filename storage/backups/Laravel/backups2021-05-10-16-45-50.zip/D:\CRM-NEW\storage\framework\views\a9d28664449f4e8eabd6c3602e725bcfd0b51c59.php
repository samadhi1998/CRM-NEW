<?php echo e($slot); ?>

<?php /**PATH D:\CRM-NEW\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>