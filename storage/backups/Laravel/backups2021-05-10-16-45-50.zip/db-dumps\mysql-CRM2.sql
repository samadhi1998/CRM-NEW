
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `CustomerID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NIC` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MobileNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Thilini Abesekara','985513150V','thiliniabesekara@gmail.com','0768811880','\"166/13,Divulapitiya,Gampaha\"','2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(2,'Thisal Samarakoon','964413350V','thisalvindulaa@gmail.com','0714567898','\"23/66,Ganemulla,Gampaha\"','2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(3,'Pubudu Madushan','975553159V','pubudumadushan@gmail.com','0776190806','\"44/3,Divulapitiya,Kaluthara\"','2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(4,'Nathasha walitharage','9867453159V','nathashawalitharage@gmail.com','0716789653','\"3rd road,Mathale\"','2021-04-20 10:26:31','2021-04-20 10:26:31',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `Added_By` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `events_added_by_foreign` (`Added_By`),
  CONSTRAINT `events_added_by_foreign` FOREIGN KEY (`Added_By`) REFERENCES `users` (`EmpID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'Meeting with  seviceperson','#df6407','2021-05-11','2021-05-07',1,'2021-04-21 06:29:59','2021-05-10 11:11:32',NULL),(2,'arrange a new meeting','#2502d4','2021-05-11','2021-05-14',1,'2021-05-10 11:08:48','2021-05-10 11:08:48',NULL);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `extra_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extra_charges` (
  `ExtraChargeID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `Type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Amount` int NOT NULL,
  `Description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `OrderID` bigint unsigned NOT NULL,
  `ServicePersonID` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ExtraChargeID`),
  KEY `extra_charges_orderid_foreign` (`OrderID`),
  KEY `extra_charges_servicepersonid_foreign` (`ServicePersonID`),
  CONSTRAINT `extra_charges_orderid_foreign` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`),
  CONSTRAINT `extra_charges_servicepersonid_foreign` FOREIGN KEY (`ServicePersonID`) REFERENCES `users` (`EmpID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `extra_charges` WRITE;
/*!40000 ALTER TABLE `extra_charges` DISABLE KEYS */;
INSERT INTO `extra_charges` VALUES (1,'ExtraCharge',5000,'delivery',4,1,'2021-05-10 10:21:26','2021-05-10 10:21:26',NULL);
/*!40000 ALTER TABLE `extra_charges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from` bigint NOT NULL,
  `to` bigint NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `FollowUpID` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_followupid_foreign` (`FollowUpID`),
  CONSTRAINT `messages_followupid_foreign` FOREIGN KEY (`FollowUpID`) REFERENCES `users` (`EmpID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,1,2,'Hello, Good Morning',1,'2021-04-21 03:28:33','2021-05-10 10:58:39',NULL),(2,1,2,'hi',1,'2021-04-21 07:36:51','2021-05-10 10:58:39',NULL),(3,1,3,'hi',0,'2021-04-21 08:21:32','2021-04-21 08:21:32',NULL),(4,1,2,'Hello',1,'2021-05-10 10:57:16','2021-05-10 10:58:39',NULL);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_100000_create_password_resets_table',1),(2,'2016_11_04_200855_create_notifications_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2021_01_17_132440_create_roles_table',1),(5,'2021_01_17_132559_create_priviledges_table',1),(6,'2021_01_17_132625_create_role_priviledges_table',1),(7,'2021_01_17_132626_create_users_table',1),(8,'2021_01_17_132849_create_tasks_table',1),(9,'2021_01_17_132913_create_products_table',1),(10,'2021_01_17_132928_create_customers_table',1),(11,'2021_01_17_132929_create_orders_table',1),(12,'2021_01_17_133035_create_extra_charges_table',1),(13,'2021_03_24_145105_create_notes_table',1),(14,'2021_04_02_124916_create_events_table',1),(15,'2021_04_05_111418_create_order_product_table',1),(16,'2021_04_12_100336_create_messages_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `NoteID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `image` mediumtext COLLATE utf8mb4_unicode_ci,
  `Description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `OrderID` bigint unsigned NOT NULL,
  `Added_By` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`NoteID`),
  KEY `notes_orderid_foreign` (`OrderID`),
  KEY `notes_added_by_foreign` (`Added_By`),
  CONSTRAINT `notes_added_by_foreign` FOREIGN KEY (`Added_By`) REFERENCES `users` (`EmpID`),
  CONSTRAINT `notes_orderid_foreign` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (1,'1620644752.jpg','need to check the customer payment details','Pre-Site-Visit',1,1,'2021-05-10 11:05:52','2021-05-10 11:07:13','2021-05-10 11:07:13');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('3718d810-afcc-4a6f-b253-a585a1c64185','App\\Notifications\\UserRegistered','App\\Models\\User',1,'{\"name\":\"Dulakshi Madumali\",\"email\":\"dulakshi@gmail.com\"}','2021-05-10 10:33:15','2021-05-10 10:31:57','2021-05-10 10:33:15',NULL),('7a157b34-aed8-42dc-9d90-5402cee1e949','App\\Notifications\\UserRegistered','App\\Models\\User',6,'{\"name\":\"Miyuki\",\"email\":\"Miyuki@gmail.com\"}',NULL,'2021-04-22 11:18:14','2021-04-22 11:18:14',NULL),('8ea68907-62d1-4ccb-a739-a0f38564e64c','App\\Notifications\\UserRegistered','App\\Models\\User',1,'{\"name\":\"Miyuki\",\"email\":\"Miyuki@gmail.com\"}','2021-04-22 13:02:48','2021-04-22 11:18:14','2021-04-22 13:02:48',NULL),('bd7bb2a5-a777-4017-9a66-f62565983904','App\\Notifications\\UserRegistered','App\\Models\\User',6,'{\"name\":\"Dulakshi Madumali\",\"email\":\"dulakshi@gmail.com\"}',NULL,'2021-05-10 10:31:57','2021-05-10 10:31:57',NULL);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_product` (
  `order_OrderID` bigint unsigned DEFAULT NULL,
  `product_ProductID` bigint unsigned DEFAULT NULL,
  `Qty` bigint unsigned NOT NULL,
  `Discounts` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  KEY `order_product_order_orderid_foreign` (`order_OrderID`),
  KEY `order_product_product_productid_foreign` (`product_ProductID`),
  CONSTRAINT `order_product_order_orderid_foreign` FOREIGN KEY (`order_OrderID`) REFERENCES `orders` (`OrderID`) ON DELETE CASCADE,
  CONSTRAINT `order_product_product_productid_foreign` FOREIGN KEY (`product_ProductID`) REFERENCES `products` (`ProductID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_product` WRITE;
/*!40000 ALTER TABLE `order_product` DISABLE KEYS */;
INSERT INTO `order_product` VALUES (1,1,3,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(2,1,1,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(2,2,2,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(2,3,1,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(3,2,2,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(3,3,1,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(4,1,1,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(4,3,2,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(5,1,1,NULL,'2021-04-22 11:46:25','2021-04-22 11:46:25',NULL),(6,1,1,NULL,'2021-05-08 08:18:26','2021-05-08 08:18:26',NULL),(6,3,1,NULL,'2021-05-08 08:18:26','2021-05-08 08:18:26',NULL),(7,1,10,NULL,'2021-05-10 10:18:09','2021-05-10 10:18:09',NULL),(8,2,10,NULL,'2021-05-10 10:20:27','2021-05-10 10:20:27',NULL);
/*!40000 ALTER TABLE `order_product` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `OrderID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `Description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Rate` int DEFAULT NULL,
  `Due_date` date DEFAULT NULL,
  `Feedback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Progress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Advance` int DEFAULT NULL,
  `Total_Price` int DEFAULT NULL,
  `Discount` int DEFAULT NULL,
  `CustomerID` bigint unsigned DEFAULT NULL,
  `QuotationEmpID` bigint unsigned DEFAULT NULL,
  `FollowUpID` bigint unsigned DEFAULT NULL,
  `CustomerCareID` bigint unsigned DEFAULT NULL,
  `TaskID` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `orders_customerid_foreign` (`CustomerID`),
  KEY `orders_quotationempid_foreign` (`QuotationEmpID`),
  KEY `orders_followupid_foreign` (`FollowUpID`),
  KEY `orders_customercareid_foreign` (`CustomerCareID`),
  KEY `orders_taskid_foreign` (`TaskID`),
  CONSTRAINT `orders_customercareid_foreign` FOREIGN KEY (`CustomerCareID`) REFERENCES `users` (`EmpID`),
  CONSTRAINT `orders_customerid_foreign` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`),
  CONSTRAINT `orders_followupid_foreign` FOREIGN KEY (`FollowUpID`) REFERENCES `users` (`EmpID`),
  CONSTRAINT `orders_quotationempid_foreign` FOREIGN KEY (`QuotationEmpID`) REFERENCES `users` (`EmpID`),
  CONSTRAINT `orders_taskid_foreign` FOREIGN KEY (`TaskID`) REFERENCES `tasks` (`TaskID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,NULL,'Invoice',NULL,'2021-04-26',NULL,'Order Confirmed',0,NULL,500,1,NULL,NULL,NULL,1,'2021-04-20 10:26:31','2021-05-10 10:11:17',NULL),(2,NULL,'Invoice',NULL,'2021-04-30',NULL,'Advance Payment Done',15000,NULL,1000,2,NULL,NULL,NULL,2,'2021-04-20 10:26:31','2021-04-22 08:49:46',NULL),(3,NULL,'Invoice',NULL,'2021-05-01',NULL,'Pre-Site Visit Done',12000,NULL,1000,3,NULL,NULL,NULL,3,'2021-04-20 10:26:31','2021-05-10 10:15:05',NULL),(4,NULL,'Invoice',NULL,'2021-05-05',NULL,'Order Confirmed',30000,NULL,1000,4,NULL,NULL,NULL,NULL,'2021-04-20 10:26:31','2021-04-21 03:26:13',NULL),(5,NULL,'Estimated Quotation',NULL,'2021-04-28',NULL,'Pre-Site Visit Done',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2021-04-22 11:46:24','2021-05-10 10:22:26',NULL),(6,NULL,'Invoice',NULL,'2021-05-29',NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,'2021-05-08 08:18:26','2021-05-08 08:18:26',NULL),(7,NULL,'Estimated Quotation',NULL,'2021-05-20',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,'2021-05-10 10:18:09','2021-05-10 10:18:09',NULL),(8,NULL,'Invoice',NULL,'2021-05-18',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2021-05-10 10:20:27','2021-05-10 10:20:27',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `priviledges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priviledges` (
  `PriviledgeID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `Description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`PriviledgeID`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `priviledges` WRITE;
/*!40000 ALTER TABLE `priviledges` DISABLE KEYS */;
INSERT INTO `priviledges` VALUES (1,'View-User','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(2,'Edit-User','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(3,'Delete-User','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(4,'Assign-Role','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(5,'Add-Product','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(6,'View-Product','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(7,'Edit-Product','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(8,'Delete-Product','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(9,'View-Task','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(10,'View-StockOut-Product','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(11,'View-InStock-Product','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(12,'View-NotAvailable-Product','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(13,'View-Orders','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(14,'View-Order-Details','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(15,'Add-Order','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(16,'Edit-Order','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(17,'Delete-Order','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(18,'Show-Invoice-Quotations','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(19,'Update-Order-Progress','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(20,'Add-Task','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(21,'Edit-Task','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(22,'Delete-Task','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(23,'Add-Charge','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(24,'View-Charge','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(25,'Edit-Charge','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(26,'Delete-Charge','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(27,'Add-Note','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(28,'View-Note','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(29,'Edit-Note','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(30,'Delete-Note','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(31,'Add-Reminder','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(32,'Edit-Reminder','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(33,'View-Reminder','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(34,'Delete-Reminder','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(35,'View-Role','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(36,'Edit-Role','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(37,'Delete-Role','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(38,'View-Report','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(39,'Add-Customer','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(40,'View-Customer','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(41,'Edit-Customer','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(42,'Delete-Customer','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(43,'Add-Role','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(44,'View-Location','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(45,'View-Feedback','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(46,'View-Chat','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(47,'View-Calendar','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(48,'View-Product-Information','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(49,'Task-Information','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(50,'Charge-Information','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(51,'View-Notification','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL);
/*!40000 ALTER TABLE `priviledges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `ProductID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Brand` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` mediumtext COLLATE utf8mb4_unicode_ci,
  `Description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Warranty` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Price` int NOT NULL,
  `Qty` int NOT NULL,
  `ReOrderLevel` int NOT NULL,
  `Status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'In Stock',
  `stock_defective` int DEFAULT '0',
  `AdminID` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ProductID`),
  KEY `products_adminid_foreign` (`AdminID`),
  CONSTRAINT `products_adminid_foreign` FOREIGN KEY (`AdminID`) REFERENCES `users` (`EmpID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Ceiling Fan','Singer','Singer Ceiling Fan.jpg','High-Grade And Beautiful','One Year Warrantly',6999,96,10,'In Stock',0,1,'2021-04-20 10:26:31','2021-05-10 10:16:19',NULL),(2,' Vista 43 Full HD Android Smart TV','Singer','SmartTV.jpg','43 FHD LED Smart ,\r\n                Resolution: 1920 x 1080  ,\r\n                Android','Three Year Warrantly',87999,190,20,'In Stock',1,1,'2021-04-20 10:26:31','2021-05-10 10:20:27',NULL),(3,' Green Inverter Air Conditioner ','Singer','Green Inverter Air Conditioner.jpg','High-Grade And Beautiful','One Year Warrantly',120419,49,5,'In Stock',0,1,'2021-04-20 10:26:31','2021-05-08 08:18:26',NULL),(4,'Domestic Water Pump','Singer','Domestic Water Pump .jpg','\"52Ft, 1.25 X 1, 0.5HP, Stainless Steel Volute Face Cover\"','One Year Warrantly',14799,30,3,'In Stock',0,1,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_priviledges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_priviledges` (
  `ID` bigint unsigned NOT NULL,
  `PriviledgeID` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  KEY `role_priviledges_id_foreign` (`ID`),
  KEY `role_priviledges_priviledgeid_foreign` (`PriviledgeID`),
  CONSTRAINT `role_priviledges_id_foreign` FOREIGN KEY (`ID`) REFERENCES `roles` (`RoleID`) ON DELETE CASCADE,
  CONSTRAINT `role_priviledges_priviledgeid_foreign` FOREIGN KEY (`PriviledgeID`) REFERENCES `priviledges` (`PriviledgeID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_priviledges` WRITE;
/*!40000 ALTER TABLE `role_priviledges` DISABLE KEYS */;
INSERT INTO `role_priviledges` VALUES (1,1,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,2,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,3,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,4,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,5,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,6,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,7,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,8,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,9,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,10,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,11,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,12,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,13,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,14,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,15,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,16,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,17,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,18,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,19,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,20,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,21,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,22,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,23,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,24,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,25,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,26,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,27,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,28,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,29,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,30,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,31,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,32,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,33,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,34,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,35,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,36,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,37,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,38,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,39,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,40,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,41,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,42,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,43,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,44,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,45,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,46,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,47,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,48,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,49,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(1,50,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(2,39,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,40,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,41,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,6,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,7,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,10,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,11,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,12,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,48,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,13,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,14,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,15,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,16,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,18,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,19,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,9,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,20,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,21,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,49,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,28,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,31,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,32,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,33,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,34,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,47,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,24,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(2,50,'2021-04-21 03:27:35','2021-04-21 03:27:35',NULL),(1,1,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,2,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,3,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,39,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,40,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,41,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,42,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,4,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,35,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,36,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,37,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,43,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,5,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,6,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,7,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,8,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,10,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,11,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,12,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,48,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,13,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,14,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,15,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,16,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,17,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,18,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,19,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,9,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,20,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,21,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,22,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,49,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,27,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,28,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,29,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,30,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,31,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,32,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,33,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,34,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,47,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,23,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,24,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,25,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,26,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,50,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,38,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,44,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,46,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(1,51,'2021-04-22 10:33:54','2021-04-22 10:33:54',NULL),(5,40,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,6,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,10,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,11,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,12,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,48,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,13,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,14,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,18,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,19,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,9,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,49,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,27,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,28,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,29,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,30,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,31,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,32,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,33,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,34,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,47,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,23,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,24,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,25,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(5,50,'2021-05-10 09:58:11','2021-05-10 09:58:11',NULL),(2,39,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,40,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,41,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,6,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,7,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,10,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,11,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,12,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,48,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,13,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,14,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,15,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,16,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,18,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,19,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,9,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,20,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,21,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,49,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,28,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,31,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,32,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,33,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,34,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,47,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,24,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,50,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL),(2,46,'2021-05-10 10:58:20','2021-05-10 10:58:20',NULL);
/*!40000 ALTER TABLE `role_priviledges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `RoleID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super-Admin','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(2,'Customer-Care-Person','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(3,'Follow-up-person','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(4,'Quotation-Team-Member','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(5,'Service-Person','2021-04-20 10:26:30','2021-04-20 10:26:30',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `TaskID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `Due_Date` date NOT NULL,
  `Description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ServicePersonID` bigint unsigned NOT NULL,
  `Added_By` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`TaskID`),
  KEY `tasks_servicepersonid_foreign` (`ServicePersonID`),
  KEY `tasks_added_by_foreign` (`Added_By`),
  CONSTRAINT `tasks_added_by_foreign` FOREIGN KEY (`Added_By`) REFERENCES `users` (`EmpID`),
  CONSTRAINT `tasks_servicepersonid_foreign` FOREIGN KEY (`ServicePersonID`) REFERENCES `users` (`EmpID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,'Completed','2021-04-29','Deliver fan and set up it','2021-04-22 08:43:42','2021-05-05 04:54:53',5,1,NULL),(2,'Completed','2021-04-28','Deliver Products','2021-04-22 08:49:46','2021-04-22 09:04:35',5,1,NULL),(3,'Open','2021-05-20','Deliver Products','2021-05-10 10:15:05','2021-05-10 10:15:05',5,2,NULL);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `EmpID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `Address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MobileNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `EmpType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `Added_By` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RoleID` bigint unsigned DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`EmpID`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_roleid_foreign` (`RoleID`),
  CONSTRAINT `users_roleid_foreign` FOREIGN KEY (`RoleID`) REFERENCES `roles` (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Samadhi Jayawardena','jayawardena141@gmail.com',NULL,'Darshani,Ethanamadala,Kalutara North','0718890568',NULL,'$2y$10$71JPx5F5/5OisD5kwGMqduWzhvFjieKaZz06cZFimWajfQVaAsN0m','Active',NULL,1,NULL,'2021-04-20 10:26:30','2021-04-20 10:26:30',NULL),(2,'Lakmini Fernando','lakmini@gmail.com',NULL,'Keselwatta, Panadure','0718897568',NULL,'$2y$10$MaGCXpBENSQBA8qP5/5GyeM0CcF9YMMHDMKYuWzg.HLmSPrWMhZMy','Active',NULL,2,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(3,'Asha Sewwandi','asha@gmail.com',NULL,'Galle, Hiniduma','0718097568',NULL,'$2y$10$mH.J5WxeURevQU6q/cXhGere649QV28b4LoK626uidwh6T/CSi.va','Active',NULL,3,NULL,'2021-04-20 10:26:31','2021-04-21 03:28:02',NULL),(4,'Annsha Mathavan','annsha@gmail.com',NULL,'Hatton','0768897568',NULL,'$2y$10$Y3v0v.tlEpvdWEho4GPJIOlvUiq/wRVWWgOs7IJfCJyrNr/7S7n9.','Active',NULL,4,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(5,'Saman Jayawardena','saman@gmail.com',NULL,'Darshani,Ethanamadala,Kalutara North','0718847568',NULL,'$2y$10$U4V8TC2weTBDzcVcZMPuau6MUpyGiM/pCTAH0SOoBdaI3ndKL1Jz.','Active',NULL,5,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(6,'Thilini Madushani','Thilini@gmail.com',NULL,'Divulapitiya,Gampaha','0716180776',NULL,'$2y$10$5.gCWY4cUKtPjtYjiEXGyesFmR1c4Csr6RdKxvb4GB2I.SAc0RkEC','Active',NULL,1,NULL,'2021-04-20 10:26:31','2021-04-20 10:26:31',NULL),(7,'Miyuki','Miyuki@gmail.com',NULL,'Darshani,ethanamadala Kalutara North','0342229106',NULL,'$2y$10$1shnr51ephWQ6oXVfG7p8.qEyQxh7kaNLzzYf.tDigKwCGnXAWr5a','Active',NULL,NULL,NULL,'2021-04-22 11:18:12','2021-04-22 11:18:12',NULL),(8,'Dulakshi Madumali','dulakshi@gmail.com',NULL,'Galle','0705802042',NULL,'$2y$10$DVqMpz75Yw.lVmqGa7UTgOSrb0TgFsPZnhPm8GBa1pdFQ7Iupxkpe','Active',NULL,2,NULL,'2021-05-10 10:31:57','2021-05-10 10:36:09',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

