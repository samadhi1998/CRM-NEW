
<?php $__env->startSection('title','Sales Report'); ?>
<?php $__env->startSection('header','Sales Report'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="container-fluid">
        <div class="col-md">           
            <form action="<?php echo e(route('report')); ?>" method="get">               
                <div class="row">
                    <div class="col-md-3" style="margin-top: 24px; margin-left: 30px">
                        <label for="">From: <input type="date" class="form-control" name="First_date"> </label>   
                    </div>
                    <div class="col-md-3" style="margin-top: 24px; margin-left: 30px">
                        <label for="">To:  <input type="date" class="form-control" name="Last_date"> </label>    
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2" style="margin-top: 5px; margin-left: 30px">
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" value="Submit">
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md">
                        <div class="card"> 
                            <div class="row invoice-header px-3 py-4">
                                <div class="col-12 text-center">
                                    <h2 class="Name">ABS-CBN CORPORATION</h2>
                                    <h5>No.95, Galle Road, Moratuwa</h5>
                                    <h6>Tel : +(94) 112 605 731</h6>
                                    <h6>Email :<a href="mailto:buyabc@abcgroup.com"> buyabc@abcgroup.com</a></h6>
                                    <hr>        
                                    <h4 style="text-align: center; color:#233554">Sales Report</h4><br>                   
                                </div>    
                                <div class="table-responsive">
                                <?php $total_s = 0; ?>
                                    <table>
                                        <tr> 
                                            <th>Order No</th>
                                            <th>Customer </th> 
                                            <th>Email</th> 
                                            <th>Updated Date</th>
                                            <th>Items</th>                                             
                                        </tr>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($order->OrderID); ?></td>
                                            <td><?php echo e($order->Customer); ?></td>
                                            <td><?php echo e($order->Email); ?></td>
                                            <td><?php echo e($order->updated_at); ?></td>
                                            <td>
                                                <ul>
                                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                         
                                                        <?php if( $order->OrderID === $item->OrderID): ?>
                                                            <?php $__currentLoopData = $item->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><?php echo e($p->Name); ?> (Rs.<?php echo e($p->Price); ?>)</li>
                                                                <?php $total_s = $total_s + ($p->Price * $p->pivot->Qty ); ?>  
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </td>                                            
                                        </tr>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                           
                                    </table>  
                                </div>
                            </div>
                            <br>
                            <div class="col-sm-3"> 
                                <h5>
                                    <span class="text-muted">Total Sales : Rs. </span> <?php echo  number_format  ($total_s)."<br>"; ?>
                                </h5>                                          
                            </div>
                            <div align="right">
                                <a class="btn btn-primary" id="printPageButton" onclick="window.print()">Print</button></a>
                            </div>
                           <br>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>    
</div>                     
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/reports/SalesReport.blade.php ENDPATH**/ ?>