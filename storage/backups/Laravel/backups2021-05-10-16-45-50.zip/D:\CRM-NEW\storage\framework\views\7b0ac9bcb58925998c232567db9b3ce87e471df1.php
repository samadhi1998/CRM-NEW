
<html>
    <head>
        <title> INVOICE </title>
        <style>
            table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            }
            td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
            }
            th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #dddddd;  
            color: black;
            }
            div.invoice-header > div >h2,h3,h4{
                text-align: center;
                margin-bottom: -12px;
                }
            h1 {
            font-size: 23px;
            margin-bottom: -10px;
            }
            h5 {
            font-size: 18px;
            margin-bottom: -23px;
            font-weight: normal;
            }        
        </style>
    </head>
    <body>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container">
                <div class="card">
                    <div class="card-header">
                        <div class="row invoice-header px-3 py-4">
                            <div class="card-body">
                                <div class="col-12 text-center">
                                    <h2 class="Name">ABS-CBN CORPORATION</h2>
                                    <h3>No.95, Galle Road, Moratuwa</h3>
                                    <h4>Tel : +(94) 112 605 731</h4>
                                    <h4>E-mail : <a href="mailto:buyabc@abcgroup.com"> buyabc@abcgroup.com</a></h4>
                                    <br><br><hr>
                                    <h2 class="Name"><?php echo e($ord->Status); ?></h2>
                                </div> 
                            </div> 
                        </div>   
                        <br><br>
                        <div>                                       
                            <h1><b>Order No #<?php echo e($ord->OrderID); ?></b></h1>
                            <h5>Payment Due: <?php echo e($ord->Due_date); ?></h5>
                            <h5>Issued: <?php echo e($ord->created_at); ?></h5>
                        </div>
                        <br><br>
                        <div>
                            <h5><b><?php echo e($ord->CustomerName); ?></b></h5>
                            <h5><?php echo e($ord->Address); ?></h5>
                            <h5><?php echo e($ord->MobileNo); ?></h5>
                            <h5><?php echo e($ord->Email); ?></h5> 
                        </div>  
                        <br><br><hr><br>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th class="text-center"> Description  </th>
                                        <th class="text-center"> Unit Price  </th>
                                        <th class="text-center"> Quantity  </th>
                                        <th class="text-center"> Total  </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $total = 0; ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td><?php echo e($ord->ProductName); ?> </td>   
                                        <td style="text-align: right"><?php echo e(number_format ($ord->Price)); ?> </td>   
                                        <td style="text-align: right"><?php echo e($ord->Qty); ?> </td>   
                                        <td style="text-align: right"><?php echo e(number_format ($ord->Price * $ord->Qty)); ?> </td>   
                                        <?php $total = $total + ($ord->Price * $ord->Qty); ?>      
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2"></td>
                                        <td colspan="2"><b>Total Amount</b></td>
                                        <td style="text-align: right"><b><?php echo number_format  ($total)."<br>"; ?>
                                    </tr> 
                                    <tr>
                                        <td colspan="2"></td>
                                        <td colspan="2"> (-) Discount</td>
                                        <td style="text-align: right"><?php echo e(number_format ($ord->Discount)); ?></td>
                                    </tr>                                                        
                                    <tr>
                                        <td colspan="2"></td>
                                        <td colspan="2" > (-) Advance</td>
                                        <td style="text-align: right"><?php echo e(number_format ($ord->Advance)); ?> </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"></td>
                                        <td colspan="2"><b>Balance</b></td>
                                        <td style="text-align: right"><b><?php echo e(number_format ($total - $ord->Discount - $ord->Advance)); ?></b></td>
                                    </tr>
                                </tfoot>                              
                            </table>
                        </div>                        
                    </div>
                </div>   
            </div>                    
            <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html><?php /**PATH D:\CRM-NEW\resources\views/orders/myEmail.blade.php ENDPATH**/ ?>