<html>
<head>
    <title> Weekly Sales Report </title>
        <head>
            <style>
                table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                max-width: 2480px;
                width: 100%;
                }
                td {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
                width: auto;
                overflow: hidden;
                word-wrap: break-word;
                }
                th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: center;
                background-color: #dddddd;  
                color: black;
                }
                h2,h3,h4{
                    text-align: center;
                    margin-bottom: -12px;
                    }   
            </style>
        </head>
        <body>
            <div class="container" style="background :none !important ">
                <div class="row justify-content-center">
                    <div class="col-md">
                        <div class="card">
                            <div class="card-body">   
                                <form action="<?php echo e(route('report')); ?>" method="get">  
                                    <div>
                                        <h2>ABS-CBN CORPORATION</h2>
                                        <h3>No.95, Galle Road, Moratuwa</h3>
                                        <h4>Tel : +(94) 112 605 731</h4>
                                        <h4>E-mail : <a href="mailto:buyabc@abcgroup.com"> buyabc@abcgroup.com</a></h4>
                                        <br><br><hr>
                                    </div>       
                                        <h2>Weekly Sales Report : <?php echo e($weekStartDate); ?>  -  <?php echo e($weekEndDate); ?> </b></h2>                             
                                        <br><br> 
                                        <div class="table-responsive">
                                        <?php $total_w = 0; ?>
                                            <table>
                                                <tr> 
                                                    <th width="5px">Order No</th>
                                                    <th width="30px">Customer </th> 
                                                    <th width="70px">Date</th>
                                                    <th width="280px">Items</th>                                             
                                                </tr>
                                                <?php $__currentLoopData = $current_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($order->OrderID); ?></td>
                                                    <td><?php echo e($order->Customer); ?></td>
                                                    <td><?php echo e($order->updated_at); ?></td>
                                                    <td>
                                                        <ul style="list-style-type:none;">
                                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                         
                                                                <?php if( $order->OrderID === $item->OrderID): ?>
                                                                    <?php $__currentLoopData = $item->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li><?php echo e($p->Name); ?> (Rs.<?php echo e($p->Price); ?> x <?php echo e($p->pivot->Qty); ?>)</li>
                                                                        <?php $total_w = $total_w + ($p->Price * $p->pivot->Qty ); ?> 
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </td>                                            
                                                </tr>   
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                           
                                            </table>  
                                            <br>
                                            <div class="col-sm-3"> 
                                            <h3 style="text-align:left">
                                                <span class="text-muted">No of Pendig Orders :  </span> <?php echo e($countQuo); ?><br>
                                                <span class="text-muted">No of Sales :  </span> <?php echo e($countInvo); ?><br>
                                                <span class="text-muted">Total Sales : Rs. </span> <?php echo  number_format  ($total_w)."<br>"; ?>
                                            </h3>                                          
                                        </div>
                                        </div>
                                    </div>                      
                                </form>              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
</html>
 


<?php /**PATH D:\CRM-NEW\resources\views\reports\test2.blade.php ENDPATH**/ ?>