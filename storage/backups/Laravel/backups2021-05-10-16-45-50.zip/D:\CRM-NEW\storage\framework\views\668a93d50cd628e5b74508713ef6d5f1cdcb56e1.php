
<?php $__env->startSection('title','Add Note'); ?>
<?php $__env->startSection('header','Add Note'); ?>
<?php $__env->startSection('content'); ?>
    
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <b>
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <b>
    </div>
  <?php endif; ?>
  
<div class="row justify-content-center">
  <div class="col-md-8">
    <div class="card">
      <div class="card-body">
        <div class="container"  style="background :none !important ">
          <form method="POST" action="/addNote" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
              <label for="OrderID"><b>Order ID: </b></label>
              <input type="text" name="OrderID" required >
              <br>
              <label for="Type"><b>Select Type : </b></label>
                <select  name="Type" style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%" >
                  <option value="" selected disabled hidden></option>
                  <option value="Pre-Site-Visit">Pre-Site-Visit</option>
                  <option value="Site-Visit">Site-Visit</option>
                  <option value="None">None</option>
                </select>
              <label for="Description" ><b>Description : </b></label>
              <textarea  name="Description"  required ></textarea>
              <br>
              <label for="file" ><b>Select Image: </b></label>
              <input type="file" name="image">
              <br>
              <br>
              <div class="text-right">
                <button type="submit"  Value="Next"class="btn btn-primary">Add Note</button>	 			
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/notes/createnote.blade.php ENDPATH**/ ?>