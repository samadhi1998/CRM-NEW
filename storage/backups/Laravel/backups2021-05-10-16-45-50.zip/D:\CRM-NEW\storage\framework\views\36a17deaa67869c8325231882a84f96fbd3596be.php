
<?php $__env->startSection('title','Charge Information'); ?>
<?php $__env->startSection('header','View Charge Information'); ?>
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $extra_charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charges): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card" >
                    <div class="card-body">
                    <h6 class="card-title"><strong> Order ID: <?php echo e($charges->OrderID); ?></strong></h6>
                        <strong><p style="text-align:left;color:#233556">
                            Extra-Charge ID : <?php echo e($charges->ExtraChargeID); ?><br>
                            Created Date : <?php echo e($charges->Created_at); ?><br> 
                        </strong></p>
                        <h6 class="card-title"><strong>Sevice Person Information:</strong></h6>
                        <p style="text-align:left;color:#233556"><strong> 
                            Service Person ID: <?php echo e($charges->ServicePersonID); ?> <br>
                            Service Person  Name :<?php echo e($charges->name); ?><br>
                            Contact Number : <?php echo e($charges->MobileNo); ?> <br>
                            Service Person Email  : <?php echo e($charges->email); ?> <br>
                        </strong></p>  
                        
                        <h6 class="card-title"><strong>Chargers Information :</strong></h6>
                        <br>
                        <table class="table table-bordered">
                            <tr>
                                <th scope="col"> Charge Type</th>
                                <th scope="col"> Charge Amount</th>
                                <th scope="col"> Charge Description</th>
                            </tr>
                            <tr>                         
                                <td><?php echo e($charges->Type); ?> </td>
                                <td> <span style="color:#fc030f">  Rs.<?php echo e(number_format( $charges->Amount, 2)); ?> </span></td>   
                                <td><?php echo e($charges-> Description); ?> </td>                       
                            </tr>
                        </table> 
                        </br>
                        </br>
                        <div class="pull-right" style="text-align: right;color:blue">
                         <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/charge/chargeInformation.blade.php ENDPATH**/ ?>