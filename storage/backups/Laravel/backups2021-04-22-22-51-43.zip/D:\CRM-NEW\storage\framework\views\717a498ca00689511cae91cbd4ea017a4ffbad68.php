
<?php $__env->startSection('title','Search Customer'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                    <table >
                        <thead >
                            <tr>
                                <th >Customer ID</th>
                                <th >Customer Name</th>
                                <th >NIC</th>
                                <th >Address</th>
                                <th >Mobile Number</th>
                                <th >Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>                                                
                                <td><?php echo e($customer['CustomerID']); ?></th>
                                <td><?php echo e($customer['Name']); ?></td>
                                <td><?php echo e($customer['NIC']); ?></td>
                                <td><?php echo e($customer['Address']); ?></td>
                                <td><?php echo e($customer['MobileNo']); ?></td>
                                <td><?php echo e($customer['Email']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
                <?php echo e($customers->links()); ?>

                <div class="pull-right" style="text-align: right;color:blue">
                    <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\customer\searchcustomer.blade.php ENDPATH**/ ?>