
<?php $__env->startSection('title','Search Task'); ?>
<?php $__env->startSection('header','Search Task'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
        <table>
            <tr>
              <th >Task ID</th>
              <th >Service Person ID</th>
              <th >Status</th>
              <th >Due Date</th>
              <th >Description</th>
              <th >Last Update At</th>
              <th >Action</th>
            </tr>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="text-align: center"><?php echo e($task['TaskID']); ?></td>
              <td style="text-align: center"><?php echo e($task['ServicePersonID']); ?></td>
              <td><?php echo e($task['Status']); ?></td>
              <td style="text-align: center"><?php echo e($task['Due_Date']); ?></td>
              <td style="text-align: center"><?php echo e($task['Description']); ?></td>
              <td style="text-align: center"><?php echo e($task['updated_at']); ?></td>
              <td>
              <?php if(Auth::user()->can('edit-task', App\Models\Task::class)): ?>
                <a href="/View-Task/edit/<?php echo e($task->TaskID); ?>" class="text-my-own-color"><span data-feather="edit"></span></a>
              <?php endif; ?>
              <?php if(Auth::user()->can('delete-task', App\Models\Task::class)): ?>
                <a href="/deleteTask/<?php echo e($task->TaskID); ?>" class="text-my-own-color"><span data-feather="trash-2"></span></a>
              <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>

          </br>
          </br>

          <?php echo e($tasks->links()); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
          </br>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\task\searchTask.blade.php ENDPATH**/ ?>