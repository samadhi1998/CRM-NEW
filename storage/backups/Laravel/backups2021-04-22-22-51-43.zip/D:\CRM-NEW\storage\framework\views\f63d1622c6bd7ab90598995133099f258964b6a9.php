
<?php $__env->startSection('title','View Backups'); ?>
<?php $__env->startSection('header','View Backups'); ?>
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->can('add-role', App\Models\Role::class)): ?>
<div class="pull-left">
    <a class="btn btn-primary" href="/Create-Backup">Create New Backup <span data-feather="plus"></a>
</div>
<?php endif; ?>
<br>
<br>
<?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
        <br>
        <div class="table-responsive">
          <table>
            <tr>
              <th >File</th>
              <th >Size</th>
              <th >Date</th>
              <th >Duration</th>
            </tr>
            <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="text-align: center"><?php echo e($backup['file_path']); ?></td>
              <td style="text-align: left"><?php echo e($backup['file_name']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/backup/backups.blade.php ENDPATH**/ ?>