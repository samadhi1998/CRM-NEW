
<?php $__env->startSection('title','Search Products'); ?>
<?php $__env->startSection('header','Search Products'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
        <div class="table-responsive">
          <table>
            <thead >
              <tr >
                <th >Admin ID</th>
                <th >Product ID</th>
                <th >Product Name</th>
                <th >Brand</th>
                <th >Product View</th>
                <th >Price</th>
                <th >Quantity</th>
                <th>Stock_Defective</th>
                <th >Description</th>
                <th >Status</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>                                                
                <th ><?php echo e($product['AdminID']); ?></th>
                <td><?php echo e($product['ProductID']); ?></td>
                <td><?php echo e($product['Name']); ?></td>
                <td><?php echo e($product['Brand']); ?></td>
                <td> <img src="<?php echo e(asset('uploads/product/'.$product->image)); ?>" width="100px;" height="100px;" alt="Product-Image">  </td>
                <td><?php echo e($product['Price']); ?></td>
                <td><?php echo e($product['Qty']); ?></td>
                <td><?php echo e($product->stock_defective); ?></td>
                <td><?php echo e($product['Description']); ?></td>
                <td><?php echo e($product['Status']); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          </div>
          </br>
          </br>

          <?php echo e($products->links()); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
          </br>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\product\searchproduct.blade.php ENDPATH**/ ?>