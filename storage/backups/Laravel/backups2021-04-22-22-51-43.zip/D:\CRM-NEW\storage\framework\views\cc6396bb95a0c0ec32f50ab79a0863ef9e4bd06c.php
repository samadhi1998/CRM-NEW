
<?php $__env->startSection('title','Search User'); ?>
<?php $__env->startSection('header','Search User'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
        <div class="table-responsive">
        <table>
          <tr>
            <th>EmpID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Address</th>
            <th>MobileNo</th>
            <th>Role</th>
            <th>Action</th>    
          </tr>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($user['EmpID']); ?></td>
            <td><?php echo e($user['name']); ?></td>
            <td><?php echo e($user['email']); ?></td>
            <td><?php echo e($user['Address']); ?></td>
            <td><?php echo e($user['MobileNo']); ?></td>
            <td><?php echo e(optional($user->roles)->name); ?></td>
            <td>
                  <?php if(Auth::user()->can('edit-user', App\Models\User::class)): ?>
                  <a href="<?php echo e(route('users.edit', $user->EmpID)); ?>" style="margin:2px" class="text-my-own-color">
                  <span data-feather="edit"></span>
                  </a>
                  <?php endif; ?>
                  <?php if(Auth::user()->can('assign-role', App\Models\User::class)): ?>
                  <a href="assignRole/<?php echo e($user->EmpID); ?>" style="margin:2px" class="text-my-own-color">
                  <span data-feather="key"></span>
                  </a>
                  <?php endif; ?>
                  <?php if(Auth::user()->can('delete-user', App\Models\User::class)): ?>
                  <a href="/deleteuser/<?php echo e($user->EmpID); ?>" style="margin:2px" class="text-my-own-color">
                  <span data-feather="trash-2"></span>
                  </a>
                  <?php endif; ?>
                </td> 
          <tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
          </br>
          </br>

          <?php echo e($users->links()); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
          </br>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\admin\users\searchUser.blade.php ENDPATH**/ ?>