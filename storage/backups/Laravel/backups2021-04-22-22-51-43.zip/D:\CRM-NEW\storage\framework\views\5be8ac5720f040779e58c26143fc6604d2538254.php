
<?php $__env->startSection('title','Product Information'); ?>
<?php $__env->startSection('header','View Product Information'); ?>
<?php $__env->startSection('content'); ?>


<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
      <div class="col-md">
         <div class="card" >
            <div class="card-body">

        
            <h6 class="card-title "><strong >Product Details :</strong></h6>
            <p style="text-align:left;color:#233556"><strong>
                  Product ID : <?php echo e($product->ProductID); ?><br>
                  Created Date : <?php echo e($product->Created_at); ?><br><br> 
            </strong></p>

            <h6 class="card-title"><strong>Admin  Information:</strong></h6>
            <p style="text-align:left;color:#233556"><strong> 
        
                 Admin ID : <?php echo e($product->AdminID); ?> <br>
                 Admin Name :<?php echo e($product->name); ?><br>
                 Contact Number : <?php echo e($product->MobileNo); ?> <br>
                 Admin Email  : <?php echo e($product->email); ?> <br>
           </strong></p>  
           <br>
           <h6 class="card-title"><strong>Product Information :</strong></h6>
            <p style="text-align:left;color:#233556"><strong> 
            <span style="color:#fc030f">  Re-Order Level  Quantity </span> of  <?php echo e($product->Name); ?> :: <span style="color:#fc030f"> <?php echo e($product->ReOrderLevel); ?></span>
           </strong></p> 
           </br> 
            <div class="table-responsive">
            <table class="table table-bordered">
            <tr>
                <th scope="col">Product Name</th>
                <th scope="col">Product Brand</th>
                <th scope="col"> Product Description</th>
                <th scope="col">Product Warranty </th>
                <th scope="col"> Product Price</th> 
                <th scope="col"> Product Quantity</th> 
                <th scope="col"> Product Status </th> 
                <th scope="col"> Stock_Defective </th> 
            </tr>
        
            <tr>                         
                <td><?php echo e($product->Name); ?> </td>
                <td><?php echo e($product->Brand); ?> </td>   
                <td><?php echo e($product-> Description); ?> </td>                       
                <td><?php echo e($product->Warranty); ?> </td>
                <td>Rs.<?php echo e(number_format($product->Price, 2)); ?></td>     
                <td><?php echo e($product->Qty); ?> </td>
                <td><?php echo e($product->Status); ?></td>     
                <td> <span style="color:#fc030f"> <?php echo e($product->stock_defective); ?></span></td> 

            </tr>
            
   </table> 
   <br>
   </br>
   </br>
   <div class="pull-right" style="text-align: right;color:blue">
    <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
   </div>
</div>
</div>
</div>
</div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\product\productInformation.blade.php ENDPATH**/ ?>