<!-- select2 -->
<?php
    $current_value = old($field['name']) ? old($field['name']) : (isset($field['value']) ? $field['value'] : (isset($field['default']) ? $field['default'] : '' ));
    $field['allows_null'] = $field['allows_null'] ?? $crud->model::isColumnNullable($field['name']);
?>

<?php echo $__env->make('crud::fields.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <label><?php echo $field['label']; ?></label>
    <?php echo $__env->make('crud::fields.inc.translatable_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php
        $related_model = $crud->getRelationModel($field['entity']);
        $group_by_model = (new $related_model)->{$field['group_by']}()->getRelated();
        $categories = $group_by_model::with($field['group_by_relationship_back'])->get();

        if (isset($field['model'])) {
            $categorylessEntries = $related_model::doesnthave($field['group_by'])->get();
        }
    ?>
    <select
        name="<?php echo e($field['name']); ?>"
        style="width: 100%"
        data-init-function="bpFieldInitSelect2GroupedElement"
        <?php echo $__env->make('crud::fields.inc.attributes', ['default_class' =>  'form-control select2_field'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        >

            <?php if($field['allows_null']): ?>
                <option value="">-</option>
            <?php endif; ?>

            <?php if(isset($field['model']) && isset($field['group_by'])): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($category->{$field['group_by_attribute']}); ?>">
                        <?php $__currentLoopData = $category->{$field['group_by_relationship_back']}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subEntry->getKey()); ?>"
                                <?php if( ( old($field['name']) && old($field['name']) == $subEntry->getKey() ) || (isset($field['value']) && $subEntry->getKey()==$field['value'])): ?>
                                     selected
                                <?php endif; ?>
                            ><?php echo e($subEntry->{$field['attribute']}); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($categorylessEntries->count()): ?>
                    <optgroup label="-">
                        <?php $__currentLoopData = $categorylessEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($current_value == $subEntry->getKey()): ?>
                                <option value="<?php echo e($subEntry->getKey()); ?>" selected><?php echo e($subEntry->{$field['attribute']}); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($subEntry->getKey()); ?>"><?php echo e($subEntry->{$field['attribute']}); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                <?php endif; ?>
            <?php endif; ?>
    </select>

    
    <?php if(isset($field['hint'])): ?>
        <p class="help-block"><?php echo $field['hint']; ?></p>
    <?php endif; ?>
<?php echo $__env->make('crud::fields.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php if($crud->fieldTypeNotLoaded($field)): ?>
    <?php
        $crud->markFieldTypeAsLoaded($field);
    ?>

    
    <?php $__env->startPush('crud_fields_styles'); ?>
        <!-- include select2 css-->
        <link href="<?php echo e(asset('packages/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('packages/select2-bootstrap-theme/dist/select2-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <?php $__env->stopPush(); ?>

    
    <?php $__env->startPush('crud_fields_scripts'); ?>
        <!-- include select2 js-->
        <script src="<?php echo e(asset('packages/select2/dist/js/select2.full.min.js')); ?>"></script>
        <?php if(app()->getLocale() !== 'en'): ?>
        <script src="<?php echo e(asset('packages/select2/dist/js/i18n/' . app()->getLocale() . '.js')); ?>"></script>
        <?php endif; ?>
        <script>
            function bpFieldInitSelect2GroupedElement(element) {
                if (!element.hasClass("select2-hidden-accessible"))
                {
                    element.select2({
                        theme: "bootstrap"
                    });
                }
            }
        </script>
    <?php $__env->stopPush(); ?>

<?php endif; ?>


<?php /**PATH D:\CRM-NEW\vendor\backpack\crud\src\resources\views\crud\fields\select2_grouped.blade.php ENDPATH**/ ?>