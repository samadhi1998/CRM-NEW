
<?php $__env->startSection('title','Out  of Stock'); ?>
<?php $__env->startSection('header','Out Of Stock'); ?>
<?php $__env->startSection('content'); ?>

<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
          <br>
          <?php if(Session::has('error')): ?>
          <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

         </div>
          <?php endif; ?>
          <form action="/Search_Products" method="GET" role="search">
            <?php echo e(csrf_field()); ?>

            <div class="input-group">
                <input type="text" class="form-control" name="query" id="query" placeholder="Search  Stock Products Details"> 
                  <span class="input-group-btn">
                    <button type="submit" class="btn btn-default">
                      <span class="glyphicon glyphicon-search"></span>
                    </button>
                  </span> 
            </div>
          </form>
          </br>
          </br>
          <div class="table-responsive">
          <table>
            <tr >
              <th >Product Name</th>
              <th >Product View</th>
              <th >Brand</th>
              <th >Price</th>
              <th >Warranty</th>
              <th> Stock_Defective</th>
              <th >Action</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>                                                
              <td><?php echo e($product->Name); ?></td>
              <td> <img src="<?php echo e(asset('uploads/product/'.$product->image)); ?>"
              class="img-circle" width="100px;" height="100px;" alt="Product-Image">  </td>
              <td><?php echo e($product->Brand); ?></td>
              <td> Rs.<?php echo e(number_format($product->Price, 2)); ?></td>
              <td><?php echo e($product->Warranty); ?></td>
              <td><?php echo e($product->stock_defective); ?></td>
              <td>  
              <?php if(Auth::user()->can('edit-product', App\Models\product::class)): ?>
                <a href= "/UpdateProducts/<?php echo e($product['ProductID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a>
              <?php endif; ?>
               <?php if(Auth::user()->can('view-product-information', App\Models\product::class)): ?>
                <a href="/ProductInformation/<?php echo e($product['ProductID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="eye"></span></a>
              <?php endif; ?> 
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </div>
          <br>
          <br>
          <?php echo e($data->links()); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\product\productNotAvailable.blade.php ENDPATH**/ ?>