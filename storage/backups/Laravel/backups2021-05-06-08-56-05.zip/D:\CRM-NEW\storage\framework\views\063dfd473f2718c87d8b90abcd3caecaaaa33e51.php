
<?php $__env->startSection('title','Customer Information'); ?>
<?php $__env->startSection('content'); ?>

<div class="container" style="background :none !important ">
<div class="row justify-content-center">
<div class="col-md">
<div class="card">
<div class="card-header"><?php echo e(__('Customer Informations')); ?></div>
<div class="card-body">
</br>

    <div class="pull-right" style="text-align: right;color:blue">
    <a href="/addCustomer" class="btn btn-primary">Back to Add Customer</a>
    </div>

<br>
<br>
                            
                <form method="post"  action= "checkcustomers" autocomplete="off">
                   <?php echo csrf_field(); ?>
                  <label class="form-control-label" for="input-name ">Customer Order Details</label>
                    <select name="CustomerID" id="input-category" class="form-select" required>
                            
                         <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($customer['CustomerID'] == old('customer')): ?>
                            <option value="<?php echo e($customer['CustomerID']); ?>" selected><?php echo e($customer['Name']); ?>  -  <?php echo e($customer['MobileNo']); ?> - <?php echo e($customer['NIC']); ?></option>
                           <?php else: ?>
                            <option value="<?php echo e($customer['CustomerID']); ?>"><?php echo e($customer['Name']); ?>  -  <?php echo e($customer['MobileNo']); ?> -  <?php echo e($customer['NIC']); ?></option>
                           <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                    </select>
<br>
<br>
                 <div class="text-right">
                 <button type="submit"  Value="Continue" class="btn btn-primary">Continue</button>	 			
                 </div>
                 </form>


                 

</div>
</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        new SlimSelect({
            select: '.form-select'
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/customer/customerorderdetail.blade.php ENDPATH**/ ?>