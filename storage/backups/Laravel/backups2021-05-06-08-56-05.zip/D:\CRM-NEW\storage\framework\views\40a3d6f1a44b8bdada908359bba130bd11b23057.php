
<?php $__env->startSection('title','Add Charge'); ?>
<?php $__env->startSection('header','Add Charge'); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
       <div class="col-md-8">
              <div class="card">
                     <div class="card-body">
                            <div class="container"  style="background :none !important ">
                                   <br>
                                   <?php if($errors->any()): ?>
                                   <div class="alert alert-danger">
                                   <b>
                                   <ul>
                                   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </ul>
                                   </b>
                                   </div>
                                    <?php endif; ?>
                                   <form method="POST" action="/addChargers">
                                          <?php echo csrf_field(); ?> 
                                          <label for="OrderID" ><b> Order ID : </b></label>
                                          <input type="text" name="OrderID"  value="<?php echo e($extra_charge->OrderID); ?>" readonly >
                                          <br>
                                          <label for="ServicePersonID" ><b>ServicePerson ID : </b></label>
                                          <input type="text" name="ServicePersonID"  value="<?php echo e(Auth::user()->EmpID); ?>" readonly>
                                          <br>
                                          <label for="Type"><b>Type : </b></label>
                                                 <select  name="Type">
                                                        <option value="" selected disabled hidden></option>
                                                        <option value="ExtraCharge">Extra Charge</option>
                                                        <option value="ServiceCharge">Service Charge</option>   
                                                 </select>
                                          <br>
                                          <label for="Amount" ><b>Amount : </b></label>
                                          <input type="number" name="Amount" min="50" >
                                          <br>
                                          <label for="Description" ><b>Description : </b></label>
                                          <textarea  name="Description" required ></textarea>
                                          <br>
                                          <div class="text-right">
                                          <button type="submit"  Value="Next"class="btn btn-primary">Submit</button>	 			
                                          </div>
                                   </form>
                            </div>
                     </div>
              </div>
       </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/charge/addcharge.blade.php ENDPATH**/ ?>