
<?php $__env->startSection('title','Sales Report'); ?>
<?php $__env->startSection('header','Daily Sales Report'); ?>
<?php $__env->startSection('content'); ?>

<div class="container " style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        ---Select Report Cetogory---
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="http://127.0.0.1:8000/byweekly">Weekly Sales Report</a>
                            <a class="dropdown-item" href="http://127.0.0.1:8000/bymonthly">Monthly Sales Report</a>
                            <a class="dropdown-item" href="http://127.0.0.1:8000/salesreport">Other Sales Report</a>
                        </div>
                    </div>
                    <form action="<?php echo e(route('report')); ?>" method="get"><br><br>
                    <div class="container " style="background :none !important ">
                        <div class="row justify-content-center">
                            <div class="col-md">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('report')); ?>" method="get"><br><br>   
                                            <div class="row invoice-header px-3 py-4">
                                                <div class="col-12 text-center">
                                                    <h2 class="Name">ABS-CBN CORPORATION</h2>
                                                    <h6>No.95, Galle Road, Moratuwa</h6>
                                                    <h6>Tel : +(94) 112 605 731</h6>
                                                    <h6><a href="mailto:buyabc@abcgroup.com">email : buyabc@abcgroup.com</a></h6>
                                                    <hr>        
                                                    <h4 style="text-align: center; color:#233554">Daily Sales Report -  <?php echo e($date); ?>  </h4>                         
                                                </div> 
                                            </div>
                                        <div>
                                    </div>
                                    <div class="table-responsive">
                                        <table>
                                            <tr> 
                                                <th>Order No</th>
                                                <th>Customer </th> 
                                                <th>Updated Date</th>
                                                <th>Products</th>                                             
                                            </tr>
                                            <?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($order->OrderID); ?></td>
                                                <td><?php echo e($order->Customer); ?></td>
                                                <td><?php echo e($order->updated_at); ?></td>
                                                <td>
                                                    <ul>
                                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                         
                                                            <?php if( $order->OrderID === $item->OrderID): ?>
                                                                <?php $__currentLoopData = $item->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li><?php echo e($p->Name); ?> (Rs.<?php echo e($p->Price); ?>)</li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </td>                                            
                                            </tr>   
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                           
                                        </table>  
                                    </div>
                                    <br><br><br><br>
                                    <div class="card" style="width: 18rem;">
                                        <ul class="list-group list-group-flush"><b>
                                            <li class="list-group-item">Date : <?php echo e($date); ?></li>
                                            <li class="list-group-item">No of Sales : <?php echo e($count); ?></li>
                                        </b></ul>
                                    </div>

                                    <div align="right">
                                        <a class="btn btn-primary" id="printPageButton" onclick="window.print()">Save</button></a>
                                        <a class="btn btn-primary" id="printPageButton" onclick="window.print()">Print</button></a>
                                    </div>
                                </div>
                        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\reports\bydaily.blade.php ENDPATH**/ ?>