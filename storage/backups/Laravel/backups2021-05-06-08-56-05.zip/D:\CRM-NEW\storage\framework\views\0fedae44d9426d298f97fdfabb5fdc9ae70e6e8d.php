
<?php $__env->startSection('title','Add Products'); ?>
<?php $__env->startSection('header','Add Product Information'); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                    <b>
                    <ul>
                   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><?php echo e($error); ?></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
                   <b>
                   </div>
                   <?php endif; ?>
                    <div class="container"  style="background :none !important ">
                        <form method="POST" action="/addproduct" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <label for="Name" ><b>Product Name : </b></label>
                            <input type="text" name="Name" required >
                            <br>
                            <label for="Brand" ><b>Brand : </b></label>
                            <input type="text" name="Brand"  >
                            <br>
                            <label for="file" ><b>Product View: </b></label>
                            <input type="file" name="image" >
                            <br>
                            <label for="Price" ><b>Price : </b></label>
                            <input type="number" name="Price" >
                            <br>
                            <label for="Qty" ><b>Quantity : </b></label>
                            <input type="number" name="Qty" >
                            <br>
                            <label for="Warranty"><b>Warranty : </b></label>
                                <select  name="Warranty" style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%" >
                                    <option value="" selected disabled hidden></option>
                                    <option value="one-year-warranty">One Year Warranty</option>
                                    <option value="two-year-Warranty">Two Year Warranty</option>
                                    <option value="three-year-Warranty">Three Year Warranty</option>
                                    <option value="No-Wrranty">No Warranty</option>
                                </select>
                            <br>
                            <label for="Description" ><b>Description : </b></label>
                            <textarea  name="Description" ></textarea>
                            <br>
                            <label for="ReOrderLevel" ><b> Re-Order Level Quantity : </b></label>
                            <input type="number" name="ReOrderLevel" >
                            <br>
                            <br>
                            <div class="text-right">
                                <button type="submit"  Value="Next"class="btn btn-primary">Add Product</button>	 			
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\product\addproduct.blade.php ENDPATH**/ ?>