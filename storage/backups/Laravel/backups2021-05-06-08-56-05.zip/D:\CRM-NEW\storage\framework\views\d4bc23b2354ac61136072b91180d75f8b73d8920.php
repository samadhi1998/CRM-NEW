
<?php $__env->startSection('title','Create Task'); ?>
<?php $__env->startSection('header','Create Tasks'); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row justify-content-center">
    <div class="col-md">
        <div class="card">
        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
            <div class="card-body">
                <div class="container"  style="background :none !important ">
                    <form method="POST" action="<?php echo e(route('task.store')); ?>" id="myform">
                        <?php echo csrf_field(); ?>
                        <label for="Description" ><b>Description : </b></label>
                        <textarea name="Description" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%" rows="5" cols="50"></textarea>
                        <br>
                        <label for="Due_Date" ><b>Due Date : </b></label>
                        <input type="date" name="Due_Date" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                        <br>
                        <label for="OrderID" ><b>Order ID : </b></label>
                        <input type="text" name="OrderID" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%" value="<?php echo e($orders->OrderID); ?>"> 
                        <br>
                        <label for="ServicePersonID"><b>Assign Employee : </b></label>
                            <select name="ServicePersonID" style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%" >
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option selected>Select a Service Person</option>
                                    <option value="<?php echo e($user['EmpID']); ?>"><?php echo e($user['name']); ?>: No of active tasks:- <?php echo e($count); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <br>
                        <label for="Status"><b>Status : </b></label>
                        <select name="Status" style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%" >
                            <option value="Open">Open</option>
                            <option value="Completed">Completed</option>
                        </select>
                        <br>
                        <br>
                        <div class="btn-group float-right" role="group">
                        <button type="submit">Create Task</button>
                        </div>
                        <div class="btn-group float-right mr-2 " role="group">
                        <button type="submit" ><a href="/View-Task" class="text-my-own-color">Cancel</a></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/task/CreateTask.blade.php ENDPATH**/ ?>