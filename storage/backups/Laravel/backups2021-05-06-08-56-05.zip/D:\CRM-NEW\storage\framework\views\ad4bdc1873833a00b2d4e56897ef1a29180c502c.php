
<?php $__env->startSection('title','Search Order'); ?>
<?php $__env->startSection('header','Search Order'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
         <table>
            <tr> 
                <th width="80px"> OrderID</th>
                <th width="80px"> Customer</th>
                <th width="100px">created_at</th> 
                <th width="100px">Progress</th>
                <th width="50px"> Status </th>
                <th width="370px">Order Items</th>
                <th width="200px">Action</th>
            </tr>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order['OrderID']); ?></td>
                <td style="text-align: left"><?php echo e(optional($order->customers)->Name); ?></td>
                <td style="text-align: left"><?php echo e($order['created_at']); ?></td>
                <td style="text-align: left"> <?php echo e($order['Progress']); ?> </td>
                <td style="text-align: left"><?php echo e($order['Status']); ?></td>
                <td style="text-align: left">
                    <ul>
                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item->Name); ?>(Rs.<?php echo e($item->Price); ?> x <?php echo e($item->pivot->Qty); ?>)</li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </td>
                <td>
                
                <a href="/vieworddetails/<?php echo e($order['OrderID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="eye"></span></a>

                <?php if(Auth::user()->can('show-Invoice-Quotation', App\Models\Order::class)): ?>
                    <a href="<?php echo e(route('orders.show',$order->OrderID)); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="file-text"></span></a>
                <?php endif; ?>

                <?php if(Auth::user()->can('edit-order', App\Models\Order::class)): ?>
                    <a href="edit/<?php echo e($order->OrderID); ?>"  style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a>
                <?php endif; ?>

                <?php if(Auth::user()->can('update-progress', App\Models\Order::class)): ?>
                    <a href= "progressedit/<?php echo e($order->OrderID); ?>" class="text-my-own-color"><span data-feather="edit-3"> </span></a>
                <?php endif; ?>

                <?php if(Auth::user()->can('add-charge', App\Models\Charge::class)): ?>
                <a href= "addChargers/<?php echo e($order->OrderID); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="dollar-sign"></span></a> 
                <?php endif; ?>

                <?php if(Auth::user()->can('delete-order', App\Models\Order::class)): ?>
                    <a href= "delete/<?php echo e($order->OrderID); ?>" class="text-my-own-color"><span data-feather="trash-2"> </span></a>
                <?php endif; ?> 

                <?php if(Auth::user()->can('add-task', App\Models\Task::class)): ?>
                    <a href= "addtask/<?php echo e($order->OrderID); ?>" class="text-my-own-color"><span data-feather="target"> </span></a>
                <?php endif; ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </br></br>
          <?php echo e($orders->links()); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
          </br>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\orders\searchorder.blade.php ENDPATH**/ ?>