<!-- This file is used to store topbar (right) items -->



<?php /**PATH D:\CRM-NEW\vendor\backpack\crud\src\resources\views\base\inc\topbar_right_content.blade.php ENDPATH**/ ?>