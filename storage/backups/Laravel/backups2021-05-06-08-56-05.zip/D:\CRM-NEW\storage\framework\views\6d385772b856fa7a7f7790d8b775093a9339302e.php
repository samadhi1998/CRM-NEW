
<?php $__env->startSection('title','Chats'); ?>
<?php $__env->startSection('header','Chats'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
<div class="card">
  <div class="row">
    <div class="col-md-4">
      <div class="user-wrapper">
      <div class="card-header">Chats</div>
        <ul class="users">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="user" id="<?php echo e($user->EmpID); ?>">
          
            <?php if($user->unread): ?>
            <span class="pending"><?php echo e($user->unread); ?></span>
           <?php endif; ?>  
            <div class="media">
              <div class="media-body">
                <div class="card text-center">
                <div class= "row no-gutters">
                <div class="col-md-4 align-self-center">
                <span data-feather="user" style="width: 50px; height: 50px" class="text-my-own-color" >
                </span>
                </div>
                <div class="col-md-8 ">
                <p class="name"><?php echo e($user->name); ?></p>
                <p class="email"><?php echo e($user->email); ?></p>
                </div>
                </div>
                </div>
              </div>
            </div>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
    <div class="col-md-8" id="messages">
        
    </div>
  </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\message\chat.blade.php ENDPATH**/ ?>