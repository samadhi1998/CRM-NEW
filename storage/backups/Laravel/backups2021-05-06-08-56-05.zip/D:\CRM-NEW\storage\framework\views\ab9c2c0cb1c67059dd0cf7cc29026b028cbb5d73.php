
<?php $__env->startSection('title','View Customer'); ?>
<?php $__env->startSection('header','Customer Details'); ?>
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->can('add-customer', App\Models\customer::class)): ?>
  <div class="pull-left" style="text-align:left;color:blue">
    <a href="/addCustomer" class="btn btn-primary"> Add Customer <span data-feather="plus"></a>
  </div>
<?php endif; ?>
<br>
<br>
<br>
<?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<div class="container " style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
          <form action="/Search_Customers" method="GET" role="search">
            <?php echo e(csrf_field()); ?>

              <div class="input-group">
                <input type="text" class="form-control" name="query" id="query" placeholder="Search Customers"> 
                <span class="input-group-btn">
                  <button type="submit" class="btn btn-default">
                    <span class="glyphicon glyphicon-search"></span>
                  </button>
                </span>
              </div>
          </form>
          </br>
          </br>
          <div class="table-responsive">
          <table>
            <thead>
              <tr>
                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('CustomerID'));?></th>
                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Name'));?></th>
                <th>Address</th>
                <th>Mobile Number</th>
                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Email'));?></th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if($customers->count()): ?>
              <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>                                                
                <th ><?php echo e($customer['CustomerID']); ?></th>
                <td style="text-align: left"><?php echo e($customer['Name']); ?></td>
                <td style="text-align: left"><?php echo e($customer['Address']); ?></td>
                <td><?php echo e($customer['MobileNo']); ?></td>
                <td style="text-align: left"><?php echo e($customer['Email']); ?></td>
                <td>
                <?php if(Auth::user()->can('edit-customer', App\Models\customer::class)): ?>
                    <a href="/editCustomer/<?php echo e($customer['CustomerID']); ?>" style="margin:2px" class="text-my-own-color"><i data-feather="edit"></i></a>
                <?php endif; ?>
                <?php if(Auth::user()->can('delete-customer', App\Models\customer::class)): ?>
                    <a href="/deleteCustomer/<?php echo e($customer['CustomerID']); ?>" style="margin:2px" class="text-my-own-color" onclick="return confirm('Are you sure you want to delete this item?');">
                  <span data-feather="trash-2"></span>
                  </a>
                <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
          </div>
          <br>
          <br>
          <?php echo $customers->appends(\Request::except('page'))->render(); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
          </br>
        </div>
      </div>
    </div>
  </div>
</div>
</br>
<script>
  feather.replace()
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\customer\viewcustomer.blade.php ENDPATH**/ ?>