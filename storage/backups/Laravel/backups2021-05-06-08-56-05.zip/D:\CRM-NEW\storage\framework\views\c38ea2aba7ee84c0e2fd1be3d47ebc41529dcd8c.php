
<?php $__env->startSection('title','Assign Role'); ?>
<?php $__env->startSection('header','Assign Role'); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
  <div class="col-md-8">
    <div class="card">
      <div class="card-body">
        <div class="container"  style="background :none !important ">
          <form method="POST" action="/assignRole" id="myform" >
            <?php echo csrf_field(); ?>
            <label for="EmpID" ><b>Emp ID : </b></label>
            <input type="text" name="EmpID" value="<?php echo e($users->EmpID); ?>" required >
            <br>
            <label for="name" ><b>Emp Name : </b></label>
            <input type="text" name="name" value="<?php echo e($users->name); ?>" required >
            <br>
            <label for="RoleID"><b>Role : </b></label>
              <select  name="RoleID" style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%" >
              <option value="<?php echo e($users->RoleID); ?>" selected hidden><?php echo e(optional($users->roles)->name); ?></option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <option value="<?php echo e($role->RoleID); ?>"><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            <br>
            <div class="btn-group float-right" role="group">
              <button type="button" data-toggle="modal" class="btn btn-primary" data-target="#exampleModal" >Assign Role</button>
            </div>
            <div class="btn-group float-right mr-2" role="group">
              <button type="submit" class="btn btn-primary" ><a href="/viewuser" style="color:white">Cancel</a></button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal for assigning role -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" style="color:#233554">Update Alert</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <div class="modal-body" style="color:#233554">
        You are going to assign employee <?php echo e($users->name); ?> a role . Do you want to continue ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" form="myform" class="btn btn-primary">Update</button>
      </div>
    </div>
  </div>
</div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\admin\users\assignrole.blade.php ENDPATH**/ ?>