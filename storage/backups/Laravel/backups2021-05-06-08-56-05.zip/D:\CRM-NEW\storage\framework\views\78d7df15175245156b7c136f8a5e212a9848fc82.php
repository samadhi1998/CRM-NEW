
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('header','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <!-- Column 1-->
            <div class="col-sm-3">
                <div class="card">
                    <div class="row no-gutters">
                        <div class="col-md-8">
                            <div class="card-body">
                                <h4 class="card-title">Orders</h4>
                                <div class="text-end">
                                    <h2 class="font-light mb-0"><i class="ti-arrow-up text-success"></i> <?php echo e($count); ?></h2>
                                    <span class="text-muted">Daily Orders</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex align-self-center">
                            <span data-feather = "shopping-cart" style="width: 70px; height: 70px" class="text-my-own-color" ></span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column 2-->
            <div class="col-sm-3">
                <div class="card">
                    <div class="row no-gutters">
                        <div class="col-md-8">
                            <div class="card-body">
                                <h4 class="card-title">Customers</h4>
                                <div class="text-end">
                                    <h2 class="font-light mb-0"><i class="ti-arrow-up text-success"></i> <?php echo e($count2); ?></h2>
                                    <span class="text-muted">Daily Customers</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex align-self-center">
                            <span data-feather = "users" style="width: 70px; height: 70px" class="text-my-own-color"></span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column 3-->
            <div class="col-sm-3">
                <div class="card">
                    <div class="row no-gutters">
                        <div class="col-md-8">
                            <div class="card-body">
                                <h4 class="card-title">Tasks</h4>
                                <div class="text-end">
                                    <h2 class="font-light mb-0"><i class="ti-arrow-up text-success"></i> <?php echo e($count3); ?></h2>
                                    <span class="text-muted">Daily Tasks</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex align-self-center">
                            <span data-feather = "target" style="width: 70px; height: 70px" class="text-my-own-color"></span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column 4-->
            <div class="col-sm-3">
                <div class="card">
                    <div class="row no-gutters">
                        <div class="col-md-8">
                            <div class="card-body">
                                <h4 class="card-title">Products</h4>
                                <div class="text-end">
                                    <h2 class="font-light mb-0"><i class="ti-arrow-up text-success"></i> <?php echo e($count4); ?></h2>
                                    <span class="text-muted">Active Products</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex align-self-center">
                            <span data-feather = "package" style="width: 70px; height: 70px" class="text-my-own-color"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>
        <br>

        <!-- ============================================================== -->
        <!-- Orders & Products -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-md-flex">
                            <h4 class="card-title col-md-10 mb-md-0 mb-5 align-self-center">Orders</h4>
                        </div>
                        <div class="table-responsive mt-4">
                            <table>
                                <tr> 
                                    <th>Order ID:</th>
                                    <th>Customer</th>
                                    <th>Due Date</th>
                                    <th>Progress</th>         
                                </tr>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->OrderID); ?></td>
                                    <td><?php echo e(optional($order->customers)->Name); ?></td>
                                    <td><?php echo e($order->Due_date); ?></td>
                                    <td><?php echo e($order->Progress); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <br>
                            <?php echo e($orders->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-md-flex">
                            <h4 class="card-title col-md-10 mb-md-0 mb-5 align-self-center">Products</h4>
                        </div>              
                        <div class="table-responsive mt-4">
                            <table>
                                <tr> 
                                    <th>Product Name:</th>
                                    <th>Description</th>
                                    <th>Quantity</th>         
                                </tr>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: left"><?php echo e($product->Name); ?></td>
                                    <td style="text-align: left"><?php echo e($product->Description); ?></td>
                                    <td><?php echo e($product->Qty); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <br>
                            <?php echo e($products->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>