
<?php $__env->startSection('title','Add Customer'); ?>
<?php $__env->startSection('header','Add Customer Information'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card">
                <div class="card-body">
                    <br>
                    <br>
                    <?php if($errors->any()): ?>
                   <div class="alert alert-danger">
                   <b>
                   <ul>
                   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><?php echo e($error); ?></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
                   </b>
                   </div>
                   <?php endif; ?>
                    <form method="POST" action="/addCustomer" id="myform">
                        <?php echo csrf_field(); ?>
                        <label for="Name" ><b> Customer Name : </b></label>
                        <input type="text" name="Name" value="<?php echo e(old(' Name ')); ?>">
                        <br>
                        <label for="MobileNo" ><b>Mobile Number : </b></label>
                        <input type="text" name="MobileNo"  value="<?php echo e(old(' MobileNo ')); ?>">
                        <br>
                        <label for="NIC" ><b>NIC : </b></label>
                        <input type="text" name="NIC" value="<?php echo e(old(' NIC ')); ?>">
                        <br>
                        <label for="Email" ><b>Email : </b></label>
                        <input type="text" name="Email" value="<?php echo e(old('Email')); ?>">
                        <br>
                        <label for="Address" ><b>Address : </b></label>
                        <input type="text" name="Address" value="<?php echo e(old('Address')); ?>">
                        <br>
                        <br>
                        <div class="text-right">
                            <button type="submit"  Value="save"class="btn btn-primary">Save</button>	 			
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\customer\addcustomer.blade.php ENDPATH**/ ?>