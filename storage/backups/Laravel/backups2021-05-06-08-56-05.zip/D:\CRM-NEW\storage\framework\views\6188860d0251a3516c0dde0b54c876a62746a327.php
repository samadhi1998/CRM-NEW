
<?php $__env->startSection('title','Reminders'); ?>
<?php $__env->startSection('header','Calendar'); ?>
<?php $__env->startSection('content'); ?>
<div class="pull-left">
    <?php if(Auth::user()->can('add-reminder', App\Models\Event::class)): ?>    
      <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary" >Add New Reminder</button>
    <?php endif; ?>
    <?php if(Auth::user()->can('view-reminder', App\Models\Event::class)): ?>
      <a class="btn btn-primary" href="/view-reminder">View Reminders </a>
    <?php endif; ?>
</div>
<br>
<br>
<br>
<?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
          <?php echo $calendar->calendar(); ?>

          <?php echo $calendar->script(); ?>

        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Reminder</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(route('addevent.store')); ?>"  id="myform">
                <?php echo csrf_field(); ?>
                <label for="title" ><b>Add Title : </b></label>
                <input type="text" name="title" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
                <label for="color" ><b>Add Color : </b></label>
                <input type="color" name="color" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
                <label for="start_date" ><b>Start Date : </b></label>
                <input type="date" name="start_date" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
                <label for="end_date" ><b>End Date : </b></label>
                <input type="date" name="end_date" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" form="myform">Add</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/Reminder/addreminder.blade.php ENDPATH**/ ?>