
<?php $__env->startSection('title','View Reminders'); ?>
<?php $__env->startSection('header','Reminder Details'); ?>
<?php $__env->startSection('content'); ?>
<div class="pull-left">
  <?php if(Auth::user()->can('add-reminder', App\Models\Event::class)): ?>
    <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary" >Add New Reminder <span data-feather="plus"></button>
  <?php endif; ?>
  <?php if(Auth::user()->can('view-calendar', App\Models\Event::class)): ?>
    <a class="btn btn-primary" href="/reminder">View Calendar </a>
  <?php endif; ?>
</div>
  <br> 
  <br>
  <br>
<?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>

<div class="container " style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
          <br>
            <form action="/Search_Reminders" method="GET" role="search">
              <?php echo e(csrf_field()); ?>

              <div class="input-group">
                <input type="text" class="form-control" name="query" id="query" placeholder="Search Reminder"> 
                <span class="input-group-btn">
                  <button type="submit" class="btn btn-default">
                    <span class="glyphicon glyphicon-search"></span>
                  </button>
                </span>
              </div>
            </form>
            </br>
            </br>
            <div class="table-responsive">
            <table>
              <tr >
                <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('title'));?></th>
                <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('start_date'));?></th>
                <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('end_date'));?></th>
                <th >Action</th>
              </tr>

              <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>                                                
                <th scope="row"><?php echo e($event['id']); ?></th>
                <td style="text-align: left"><?php echo e($event['title']); ?></td>
                <td><?php echo e($event['start_date']); ?></td>
                <td><?php echo e($event['end_date']); ?></td>
                <td>
                  <?php if(Auth::user()->can('edit-reminder', App\Models\Event::class)): ?>
                    <a href= "/editeventurl/update/<?php echo e($event['id']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a>                           
                  <?php endif; ?>
                  <?php if(Auth::user()->can('delete-reminder', App\Models\Eveent::class)): ?> 
                    <a href= "/deleteeventurl/<?php echo e($event['id']); ?>" style="margin:10px" class="text-my-own-color"  onclick="return confirm('Are you sure you want to delete this item?');"><span data-feather ="trash-2"></span></a> 
                  <?php endif; ?>
                </td>
              </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            </div>
            <br>
            <br> 
            <?php echo $events->appends(\Request::except('page'))->render(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Reminder</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(route('addevent.store')); ?>"  id="myform">
                <?php echo csrf_field(); ?>
                <label for="title" ><b>Add Title : </b></label>
                <input type="text" name="title" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
                <label for="color" ><b>Add Color : </b></label>
                <input type="color" name="color" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
                <label for="start_date" ><b>Start Date : </b></label>
                <input type="date" name="start_date" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
                <label for="end_date" ><b>End Date : </b></label>
                <input type="date" name="end_date" required style="background: #ffffff; margin: 5px 0 22px 0; border: none; padding: 10px; width: 100%">
                <br>
            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" form="myform">Add</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\Reminder\viewreminder.blade.php ENDPATH**/ ?>