
<?php $__env->startSection('title','Task Information'); ?>
<?php $__env->startSection('header','View Task Information'); ?>
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card" >
                <div class="card-body">
                    <h6 class="card-title "><strong >Task Details :</strong></h6>
                    <p style="text-align:left;color:#233556"><strong>
                        Task ID : <?php echo e($task->TaskID); ?><br>
                        Created Date : <?php echo e($task->created_at); ?><br><br> 
                    </strong></p>

                    <h6 class="card-title"><strong>Task Added By :</strong></h6>
                    <p style="text-align:left;color:#233556"><strong> 
                
                        Added By : <?php echo e($task->EmpID); ?> <br>
                        Name :<?php echo e($task->name); ?><br>
                        Contact Number : <?php echo e($task->MobileNo); ?> <br>
                        Email  : <?php echo e($task->email); ?> <br>
                    </strong></p>  
                    <br>
                    <h6 class="card-title"><strong>Task Information :</strong></h6>
                    <br>
                    <table class="table table-bordered">
                        <tr>
                            <th scope="col">Task ID</th>
                            <th scope="col">Description</th>
                            <th scope="col"> Order ID</th>
                            <th scope="col">Customer ID </th>
                            <th scope="col"> Due Date</th> 
                            <th scope="col"> Status</th> 
                            <th scope="col"> Created Date</th> 
                        </tr>
            
                        <tr>                         
                            <td><?php echo e($task->TaskID); ?> </td>
                            <td><?php echo e($task->Description); ?> </td>   
                            <td><?php echo e($task-> OrderID); ?> </td>                       
                            <td><?php echo e($task->CustomerID); ?> </td>
                            <td><?php echo e($task->Due_Date); ?></td>
                            <td><?php echo e($task->Status); ?></td>        
                            <td><?php echo e($task->created_at); ?> </td>  
                        </tr>
                    </table> 
                    <br>
                    <div class="btn-group pull-right" role="group">
                    <?php if(Auth::user()->can('view-order-details', App\Models\Order::class)): ?>
                        <a href="/vieworddetails/<?php echo e($task->OrderID); ?>" style="margin:2px" class="text-my-own-color"><button><span data-feather ="eye"></span> View Order Details</button></a>
                    <?php endif; ?>
                    <?php if( $task->Status == 'Open' ): ?>
                        <a href="/completeTask/<?php echo e($task->TaskID); ?>" class="text-my-own-color"><button><span data-feather="check-circle"></span> Mark as Completed</button></a>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/task/viewtaskinfo.blade.php ENDPATH**/ ?>