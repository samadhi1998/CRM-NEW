
<?php $__env->startSection('title','Orders'); ?>
<?php $__env->startSection('header','View Orders'); ?>
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->can('add-order', App\Models\Order::class)): ?>
<div class="pull-left">
    <a class="btn btn-primary" href="/searchordercustomer"> Add new order <span data-feather="plus"></a></a>
</div>
<?php endif; ?>

<br>
<br>
<?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>

<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card">
                <div class="card-body">         
                    <form action="/SearchOrder" method="GET" role="search">
                        <?php echo e(csrf_field()); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="query" id="query" placeholder="Search Orders"> <span class="input-group-btn">
                            <button type="submit" class="btn btn-default">
                                <span class="glyphicon glyphicon-search"></span>
                            </button>
                        </div>
                    </form>
                    </br></br>
                    <div class="table-responsive">
                        <table>
                            <tr> 
                                <th width="80px">  <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('OrderID'));?> </th>
                                <th width="80px">  Customer </th>
                                <th width="100px"> <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at'));?> </th> 
                                <th width="100px"> Progress </th>
                                <th width="50px">  Status </th>
                                <th width="370px"> Order Items </th>
                                <th width="200px"> Action </th>
                            </tr>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order['OrderID']); ?></td>
                                <td style="text-align: left"> <?php echo e(optional($order->customers)->Name); ?> </td>
                                <td style="text-align: left"> <?php echo e($order['created_at']); ?> </td>
                                <td style="text-align: left"> <?php echo e($order['Progress']); ?> </td>
                                <td style="text-align: left"> <?php echo e($order['Status']); ?> </td>
                                <td style="text-align: left">
                                    <ul>
                                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($item->Name); ?>(Rs.<?php echo e($item->Price); ?> x <?php echo e($item->pivot->Qty); ?>)</li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </td>
                    
                                <td>

                                <div class="btn-group" role="group">

                                <?php if(Auth::user()->can('view-order-details', App\Models\Order::class)): ?>
                                <a href="/vieworddetails/<?php echo e($order['OrderID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="eye"></span></a>
                                <?php endif; ?>
                                
                                <?php if(Auth::user()->can('edit-order', App\Models\Order::class)): ?>
                                    <a href="edit/<?php echo e($order->OrderID); ?>"  style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a>
                                <?php endif; ?>
                                
                                <?php if(Auth::user()->can('update-progress', App\Models\Order::class)): ?>
                                    <a href= "progressedit/<?php echo e($order->OrderID); ?>" style="margin:2px" class="text-my-own-color"><span data-feather="edit-3"> </span></a>
                                <?php endif; ?>

                                <?php if(Auth::user()->can('show-Invoice-Quotation', App\Models\Order::class)): ?>
                                    <a href="<?php echo e(route('orders.show',$order->OrderID)); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="file-text"></span></a>
                                <?php endif; ?>

                                <?php if(Auth::user()->can('add-charge', App\Models\Charge::class)): ?>
                                <a href= "addChargers/<?php echo e($order->OrderID); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="dollar-sign"></span></a> 
                                <?php endif; ?>

                                <?php if(Auth::user()->can('delete-order', App\Models\Order::class)): ?>
                                <a href="/delete/<?php echo e($order->OrderID); ?>" class="text-my-own-color" style="margin:2px" onclick="return confirm('Are you sure you want to delete this item?');"><span data-feather="trash-2"></span></a>
                                <?php endif; ?> 

                                <?php if(Auth::user()->can('add-task', App\Models\Task::class)): ?>
                                    <a href= "addtask/<?php echo e($order->OrderID); ?>" class="text-my-own-color" style="margin:2px"><span data-feather="target"> </span></a>
                                <?php endif; ?>
                                
                                </div>

                                </td>    
                            </tr>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table> 
                        <br> 
                        <?php echo $orders->appends(\Request::except('page'))->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/orders/index.blade.php ENDPATH**/ ?>