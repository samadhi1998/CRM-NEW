
<?php $__env->startSection('title','View Products'); ?>
<?php $__env->startSection('header','Product Details'); ?>
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->can('add-product', App\Models\product::class)): ?>
<div class="pull-left">
    <a class="btn btn-primary" href="/addproduct">Add new product <span data-feather="plus"></a>
</div>
<?php endif; ?>

<div class="pull-right" style="text-align: right;">
    <?php if(Auth::user()->can('Stock-In-product', App\Models\product::class)): ?>
    <a class="btn btn-primary" href="/InStockProducts"> In Stock</a>
    <?php endif; ?>
    <?php if(Auth::user()->can('Stock-out-product', App\Models\product::class)): ?>
    <a class="btn btn-primary"  href="/ReOrderProducts">Re Order</a>
    <?php endif; ?>
    <?php if(Auth::user()->can('Not-Available-product', App\Models\product::class)): ?>
    <a class="btn btn-primary" href="/notAvailableProducts">Out of Stock</a>
    <?php endif; ?>
</div>
  <br>
  <br>
  <br>
  <?php if(Session::has('error')): ?>
       <div class="alert alert-danger" role="alert">
           <?php echo e(Session::get('error')); ?>

       </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>

<div class="container " style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
          <br>
          <form action="/Search_Products" method="GET" role="search">
            <?php echo e(csrf_field()); ?>

            <div class="input-group">
              <input type="text" class="form-control" name="query" id="query" placeholder="Search stock Products">
                <span class="input-group-btn">
                  <button type="submit" class="btn btn-default">
                    <span class="glyphicon glyphicon-search"></span>
                  </button>
                </span>
            </div>
          </form>

          </br>
          </br>
          <div class="table-responsive">
          <table>
            <tr >
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Name'));?></th>
              <th >Product View</th>
              <th >Brand</th>
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Price'));?></th>
              <th ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Qty'));?></th>
              <th>Stock_Defective</th>
              <th >Status</th>
              <th >Action</th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>                                                
              <td style="text-align: left"><?php echo e($product['Name']); ?></td>
              <td> <img src="<?php echo e(asset('uploads/product/'.$product->image)); ?>"
              class="img-circle" width="100px;" height="100px;" alt="Product-Image">  </td>

              <td><?php echo e($product['Brand']); ?></td>
              <td>Rs.<?php echo e(number_format($product->Price, 2)); ?></td>
              <td><?php echo e($product['Qty']); ?></td>
              <td><?php echo e($product->stock_defective); ?></td>
              <td <?php if($product['Status']=='Reorder level'): ?> style="color: red;" <?php endif; ?>
               <?php if($product['Status']=='Out of Stock'): ?> style="color: red;" <?php endif; ?> ><?php echo e($product['Status']); ?></td>

              <td>
              <?php if(Auth::user()->can('view-product-information', App\Models\product::class)): ?>
                <a href="/ProductInformation/<?php echo e($product['ProductID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="eye"></span></a>
              <?php endif; ?>
              <?php if(Auth::user()->can('edit-product', App\Models\product::class)): ?>
                <a href= "/UpdateProducts/<?php echo e($product['ProductID']); ?>" style="margin:2px" class="text-my-own-color"><span data-feather ="edit"></span></a>                               
              <?php endif; ?>
              <?php if(Auth::user()->can('delete-product', App\Models\product::class)): ?>
                <a href="/Delete_Products/<?php echo e($product['ProductID']); ?>" style="margin:2px" class="text-my-own-color" onclick="return confirm('Are you sure you want to delete this item?');">
                  <span data-feather="trash-2"></span>
                  </a>
              <?php endif; ?>
              </td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </div>
          <br>
          <br>
          <?php echo $products->appends(\Request::except('page'))->render(); ?>

          <div class="pull-right" style="text-align: right;color:blue">
            <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/product/viewproduct.blade.php ENDPATH**/ ?>