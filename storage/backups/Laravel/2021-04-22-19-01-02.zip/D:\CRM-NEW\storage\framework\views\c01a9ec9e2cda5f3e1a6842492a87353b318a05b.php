
<?php $__env->startSection('title','Notifications'); ?>
<?php $__env->startSection('header','View Notifications'); ?>
<?php $__env->startSection('content'); ?>

<div class="container" style="background :none !important ">
  <div class="row justify-content-center">
    <div class="col-md">
      <div class="card">
        <div class="card-body">
            <div class="table-responsive">
          <table>
            <tr>
              <th >Notification</th>
              <th >Read At</th>
              <th >Recieved At</th>
            </tr>
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="text-align: left"><?php echo e($notification->data['name']); ?> registered into system using <?php echo e($notification->data['email']); ?></td>
              <td><?php echo e($notification['read_at']); ?></td>
              <td><?php echo e($notification['created_at']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/notification/index.blade.php ENDPATH**/ ?>