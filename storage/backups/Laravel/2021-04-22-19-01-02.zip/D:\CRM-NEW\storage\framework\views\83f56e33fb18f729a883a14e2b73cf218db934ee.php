
<?php $__env->startSection('title','Order Details'); ?>
<?php $__env->startSection('header','View Order Details'); ?>
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card" >
                <div class="card-body">
                    <h4><strong>Order No : <?php echo e($order->OrderID); ?></strong></h4><br>
                    <h5 class="card-title "><strong >Order Details :</strong></h5>
                    <h6 style="text-align:left"><strong>
                            Due Date : <?php echo e($order->Due_date); ?><br>
                            Created Date : <?php echo e($order->Created_at); ?><br><br>
                            Progress :  <?php echo e($order->Progress); ?><br>
                            Status :  <?php echo e($order->Status); ?><br><br>   
                    </strong></h6>          
                    <h5 class="card-title"><strong>Customer :</strong></h5>
                            <h6><strong> 
                                Name :<?php echo e($order->CustomerName); ?><br>
                                Address : <?php echo e($order->Address); ?> <br>
                                Mobile No : <?php echo e($order->MobileNo); ?> <br>
                                E-mail : <?php echo e($order->Email); ?> <br><br>
                            </strong></h6>  
                        <h5 class="card-title"><strong>Order Items :</strong></h5>
                            <table class="table table-bordered">
                                    <tr>
                                        <th scope="col">Description</th>
                                        <th scope="col">Unit Price</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Total</th>  
                                    </tr>     
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($ord->ProductName); ?> </td>   
                                        <td><?php echo e($ord->Price); ?> </td>   
                                        <td><?php echo e($ord->Qty); ?> </td>   
                                        <td><?php echo e($ord->Price * $ord->Qty); ?> </td>        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td colspan="2"><b>Discount</b></td>
                                        <td><?php echo e($ord->Discount); ?>  </td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td colspan="2"><b>Advance Payment</b></td>
                                        <td><?php echo e($ord->Advance); ?>  </td>
                                    </tr>
                            </table>                         
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php break; ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php $__env->stopSection(); ?>



     
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views\orders\view.blade.php ENDPATH**/ ?>