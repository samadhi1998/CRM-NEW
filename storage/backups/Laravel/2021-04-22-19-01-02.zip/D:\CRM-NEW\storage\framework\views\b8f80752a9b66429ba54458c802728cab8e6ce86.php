
<?php $__env->startSection('title','Add Order'); ?>
<?php $__env->startSection('header','Create Order'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="background :none !important ">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('orders.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>     
                    <label for="CustomerID" ><b>Customer ID : </b></label>
                    <input type="text" name="CustomerID" class="form-control" value="<?php echo e($customers->CustomerID); ?>" readonly>
                    <br><br>
                    <label for="Name" ><b>Customer Name : </b></label>
                    <input type="text" name="Name" class="form-control" value="<?php echo e($customers->Name); ?>" readonly>
                    <br><br>
                    <label for="Due_date" ><b>Due Date : </b></label>
                    <input type="date" name="Due_date" class="form-control">
                    <br><br>
                    <label for="Status"><b>Status : </b></label>
                    <select class="form-control" id="type"  name="Status">
                        <option value="" selected disabled hidden></option>
                        <option value="Estimated Quotation">Estimated Quotation</option>
                        <option value="Invoice">Invoice</option>
                    </select>   
                    <br><br>
                    <?php if(session('status')): ?>
                    <div class = "alert alert-danger">
                     <strong>Whoops!</strong> There were some problems with your input !!<br><br>
                        <ul>
                            <li> <?php echo e(session('status')); ?> </li>
                        </ul>
                    </div>
                    <?php endif; ?>   
                    <label for="Order_Items "><b>Order Items : </b></label><br><br>
                    <table class="table" id="products_table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="product0">
                                <td>
                                    <select name="products[]" class="form-control">
                                        <option value="">-- choose product --</option>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($product->ProductID); ?>">
                                                <?php echo e($product->Name); ?> (Rs.<?php echo e(number_format($product->Price, 2)); ?> )
                                                -- Only <?php echo e($product->Qty); ?> left in the stock --
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td>
                                    <input type="number" name="quantities[]" class="form-control" value="1" />
                                </td>
                            </tr>
                            <tr id="product1"></tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td><b>Discount</b></td>  
                                <td><b><input type="number" name="Discount" class="form-control"></b></td>     
                            </tr> 
                            <tr>
                                <td><b>Advance</b></td>  
                                <td><b><input type="number" name="Advance" class="form-control"></b></td>     
                            </tr> 
                        </tfoot>             
                    </table>
                    <div class="row">
                        <div class="col-md-12">
                            <button id="add_row" class="btn btn-outline-primary pull-left">+ Add Row</button>
                            <button id='delete_row' class="pull-right btn btn-outline-danger">- Delete Row</button>
                        </div>
                    </div>
                    <br><br>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">Add Order</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CRM-NEW\resources\views/orders/create.blade.php ENDPATH**/ ?>